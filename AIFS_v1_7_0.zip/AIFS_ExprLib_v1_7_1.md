# ═══════════════════════════════════════════════════
# AIFS ExprLib v1.7.1 · Expression Library
# AI 身份保真系統 · 表情庫獨立模組
# ═══════════════════════════════════════════════════
#
# 使用方式：
#   本模組與 AIFS_v1_7_0.md 搭配使用
#   不可單獨使用（需要 AIFS 主體的 ML 值與 ML_Z_derived 進行換算）
#
# 核心邏輯：
#   XY delta：EXP_DELTA_XY = ExprLib.ratio × ML值（同 v1.6.0）
#   Z  delta：EXP_DELTA_Z  = ExprLib.Z_ratio × ML_Z_derived值（v1.7.0 新增）
#   T4 驗證：ratio ≤ 1.0 → 自動合格（XY + Z 均不超出物理極限）
#
# Z_ratio 說明：
#   僅 jaw / cp / mcl / bf / br / eo 有 Z 分量（有三維運動的肌肉）
#   其餘欄位無 Z_ratio（純平面運動）
#   Z_ratio 與 XY ratio 獨立，可分別為不同值
#   Z_ratio 的意義：「Z 分量的強度，相對於該欄位 ML_Z_derived 上限」
#
# 版本歷程：
#   v1.6.0  從 AIFS 主體抽離為獨立模組
#           改用比值系統（0.0–1.0）
#           表情從 7 個擴充至 64 個
#   v1.7.0  新增 Z_ratio 欄位（三維表情動作）
#           EXP_DELTA 擴為 XY + Z 雙分量
#           表情庫不新增或移除表情，僅補充 Z 分量
#           64 個表情全部補入 Z_ratio 區塊（無 Z 分量者標記 Z: none）
#
# ═══════════════════════════════════════════════════

---

## 【比值欄位對照表】

| 欄位 | 對應 ML | 說明 |
|------|---------|------|
| `mcl` | ML_mcl | 嘴角上揚 |
| `mcd` | ML_mcd | 嘴角下拉 |
| `mwd` | ML_mwd | 嘴角外張（開口寬度增加）|
| `jaw` | ML_jaw | 開口幅度（下巴往下張開）|
| `esq` | ML_esq | 瞇眼程度（眼高縮減）|
| `eo`  | ML_eo  | 睜眼程度（眼高增加）|
| `br`  | ML_br  | 揚眉幅度 |
| `bf`  | ML_bf  | 皺眉幅度（內眥距縮減）|
| `cp`  | ML_cp  | 顴部上推（笑容時顴骨隆起）|
| `nf`  | ML_nf  | 鼻翼張開 |
| `jw`  | ML_jw  | 大笑下頜最寬（jaw_width 增量）|

**Z 軸分量欄位（v1.7.0 新增，對應 ML_Z_derived）：**

| Z 欄位 | 對應 ML_Z_derived | 方向 | 說明 |
|--------|-------------------|------|------|
| `jaw_Z` | ML_jaw_Z = ML_jaw × 0.25 | Z− | 下頜弧形後縮（TMJ 轉動）|
| `cp_Z`  | ML_cp_Z  = ML_cp × 0.40  | Z+ | 顴部前凸（笑肌推前）|
| `mcl_Z` | ML_mcl_Z = ML_mcl × 0.25 | Z+ | 嘴角弧形前移 |
| `bf_Z`  | ML_bf_Z  = ML_bf × 0.25  | Z− | 眉頭後縮下壓 |
| `br_Z`  | ML_br_Z  = ML_br × 0.20  | Z+ | 揚眉前凸 |
| `eo_Z`  | ML_eo_Z  = ML_eo × 0.12  | Z+ | 睜眼輕微前移 |

**Z_ratio 使用規則：**
- Z_ratio 與 XY ratio 獨立，可不同（例如 jaw 大幅張開但後縮分量不一定等比）
- 若表情對某肌肉的 Z 分量貢獻為零，不列出（缺省 = 0）
- 表情無任何 Z 分量時標記 `Z: none`

**軟組織欄位（無 ML 對應，ratio 直接縮放）：**

| 欄位 | 說明 | 縮放基準 |
|------|------|----------|
| `jaw_tension` | 下頜張力（緊繃感）| 0=放鬆，1=最緊繃 |
| `brow_tension` | 眉間張力（蹙眉感）| 正值=緊繃，負值=放鬆 |
| `lip_pressure` | 唇部張力（抿唇感）| 0=放鬆，1=最緊繃 |
| `eye_wet` | 眼眶濕潤（描述用，無幾何 delta）| 0=乾燥，1=淚盈眶 |
| `asym` | 不對稱係數 | 正值=右側偏移，負值=左側偏移（0.0–1.0）|

**說明：**
- 未列出的欄位 = 0.0（neutral，無動作）
- 負值的 `brow_tension` / `jaw_tension` / `lip_pressure` 表示該部位比 neutral 更放鬆
- `asym` 為方向修飾符，與其他欄位組合使用

---

## 【使用方式說明】

```
呼叫格式：AIFS:GEN:EXPR [表情名稱] [low/medium/high]
          強度可省略，預設 medium

計算流程（v1.7.0）：
  1. 查找表情 → 取得 ratio 組合（XY）與 Z_ratio 組合（Z）
  2. XY：delta_XY = ratio × ML_lock 對應值
  3. Z ：delta_Z  = Z_ratio × ML_Z_derived 對應值
  4. Z_eff：Z_eff = G9_[pt].Z + delta_Z（代入 MPIF 視差計算）
  5. 代入 prompt 的 [EXPRESSION] 段（XY + Z 描述）與 [MPIF] 段（Z_eff 視差）
  6. 使用前確認：person.ML_conf ≥ expr.min_conf，否則標記 identity_confidence:low

範例：
  AIFS:GEN:EXPR smile_open medium，轉頭 15°
  → XY: Δmcl=0.14, Δcp=0.07, Δjaw=0.08, Δesq=0.01
  → Z:  Δjaw_Z=−0.020, Δcp_Z=+0.028, Δmcl_Z=+0.035
  → Z_eff: menton_Z_eff=0.22−0.020=+0.200, zygomatic_Z_eff=0.08+0.028=+0.108
  → 視差(15°): chin shifts 0.200×tan(15°)=0.054 AU（比 neutral 0.059 稍小，真實）
               cheekbones shift 0.108×tan(15°)=0.029 AU（比 neutral 0.021 大，真實）
```

---

## 【表情庫總覽】

| 類別 | 數量 | 表情名稱 |
|------|------|----------|
| 基礎情緒 | 11 | smile_subtle, smile_open, laugh, surprise, serious, contempt, anger, fear, sadness, disgust, crying |
| 複合情緒 | 30 | embarrassment, shame, guilt, pride, relief, gratitude, longing, nostalgia, envy, boredom, confusion, determination, hesitation, anxiety, nervousness, awe, wonder, curiosity, excitement, anticipation, satisfaction, disappointment, frustration, resignation, melancholy, tenderness, adoration, suspicion, wariness, calculating |
| 社交/表演性 | 11 | polite_smile, forced_smile, bitter_smile, wry_smile, hollow_laugh, nervous_laugh, smug, arrogance, mockery, playful, speaking |
| 過渡/壓抑狀態 | 6 | suppressing_tears, suppressing_laugh, choking_up, crying_while_smiling, shock, dissociation |
| 生理狀態 | 6 | pain, exhaustion, nausea, drowsy, drunk, yawning |
| **合計** | **64** | |

---

## 【一、基礎情緒】

### smile_subtle（微笑）
> 嘴角自然上揚，眼輪匝肌輕度參與，Duchenne 型微笑

```yaml
smile_subtle:
  min_conf: est
  low:
    mcl: 0.30
    cp : 0.20
  medium:
    mcl: 0.50
    cp : 0.35
  high:
    mcl: 0.70
    cp : 0.50
  Z:
    # 微笑時 Z 分量小但真實存在
    mcl_Z: 0.30   # 嘴角輕微前移（與 mcl medium 同比例）
    cp_Z : 0.25   # 顴部微前凸
```

---

### smile_open（開口笑）
> 嘴唇分開，上排牙齒可見，顴部明顯上推，眼睛因顴部隆起而輕微瞇起

```yaml
smile_open:
  min_conf: measured
  low:
    mcl: 0.50
    cp : 0.40
    jaw: 0.15
    esq: 0.10
  medium:
    mcl: 0.70
    cp : 0.55
    jaw: 0.25
    esq: 0.20
  high:
    mcl: 0.90
    cp : 0.70
    jaw: 0.40
    esq: 0.30
  Z:
    jaw_Z: 0.60   # 開口後縮，比例略低於 jaw XY（弧形運動初段後縮較小）
    cp_Z : 0.70   # 顴部明顯前凸
    mcl_Z: 0.60   # 嘴角前移明顯
```

---

### laugh（大笑）
> 全臉參與的開懷笑，下頜張開，鼻翼微撐，顴部大幅上推

```yaml
laugh:
  min_conf: measured
  low:
    mcl: 0.60
    cp : 0.55
    jaw: 0.35
    esq: 0.25
    nf : 0.15
    jw : 0.20
  medium:
    mcl: 0.80
    cp : 0.75
    jaw: 0.55
    esq: 0.40
    nf : 0.25
    jw : 0.40
  high:
    mcl: 1.00
    cp : 1.00
    jaw: 0.80
    esq: 0.60
    nf : 0.40
    jw : 0.70
  Z:
    jaw_Z: 0.80   # 大笑時下頜大幅後縮，Z 分量隨 jaw 等比放大
    cp_Z : 1.00   # 顴部最大前凸，大笑的三維特徵最明顯
    mcl_Z: 1.00   # 嘴角最大前移
```

---

### surprise（驚訝）
> 眼睛睜大、眉毛上揚、下巴微張，屬「開口+揚眉」型

```yaml
surprise:
  min_conf: measured
  low:
    eo : 0.40
    br : 0.35
    jaw: 0.15
  medium:
    eo : 0.65
    br : 0.60
    jaw: 0.35
  high:
    eo : 1.00
    br : 1.00
    jaw: 0.60
  Z:
    jaw_Z: 0.55   # 開口後縮，驚訝時下頜弧形後縮
    br_Z : 0.80   # 揚眉前凸明顯，驚訝的立體特徵
    eo_Z : 0.80   # 睜眼前移，眼皮往前開
```

---

### serious（嚴肅）
> 接近 neutral，嘴角輕微下拉，眉間略緊，唇部輕壓
> 注意：serious 本質上是「去笑意的 neutral」，不是強烈情緒

```yaml
serious:
  min_conf: low_est
  low:
    brow_tension: 0.20
    mcd         : 0.10
  medium:
    brow_tension: 0.35
    mcd         : 0.20
    lip_pressure: 0.20
  high:
    brow_tension: 0.55
    mcd         : 0.35
    lip_pressure: 0.40
  Z: none   # 純平面動作，無明顯三維分量
```

---

### contempt（輕蔑）
> 嘴角單側上揚（不對稱），眼睛微瞇，帶有俯視感

```yaml
contempt:
  min_conf: low_est
  low:
    mcl : 0.20
    asym: +0.40    # 右側偏移
  medium:
    mcl : 0.35
    esq : 0.15
    asym: +0.60
  high:
    mcl : 0.50
    esq : 0.25
    asym: +0.80
  Z:
    mcl_Z: 0.20   # 單側嘴角輕微前移（不對稱，Z 分量較小）
```

---

### anger（憤怒）
> 眉頭下壓內縮，眼睛半瞇，鼻翼微張，下頜緊繃，唇緊閉

```yaml
anger:
  min_conf: est
  low:
    bf          : 0.35
    brow_tension: 0.35
    jaw_tension : 0.30
    esq         : 0.20
    lip_pressure: 0.25
  medium:
    bf          : 0.60
    brow_tension: 0.60
    jaw_tension : 0.55
    esq         : 0.40
    lip_pressure: 0.45
    nf          : 0.30
  high:
    bf          : 0.90
    brow_tension: 0.90
    jaw_tension : 0.80
    esq         : 0.60
    lip_pressure: 0.65
    nf          : 0.55
    mcd         : 0.20
  Z:
    bf_Z: 0.70   # 眉頭下壓後縮，憤怒時眉間組織往後壓最明顯
```

---

### fear（恐懼）
> 眼睛睜大、眉毛揚起帶蹙眉（內側揚），唇部緊壓，區別於 surprise 的眉型

```yaml
fear:
  min_conf: est
  low:
    eo          : 0.45
    br          : 0.40
    brow_tension: 0.25
    lip_pressure: 0.20
  medium:
    eo          : 0.70
    br          : 0.65
    brow_tension: 0.45
    lip_pressure: 0.35
    jaw         : 0.10
  high:
    eo          : 1.00
    br          : 0.90
    brow_tension: 0.65
    lip_pressure: 0.55
    jaw         : 0.25
    jaw_tension : 0.40
  Z:
    br_Z : 0.70   # 揚眉前凸（內側帶恐懼型弧形）
    eo_Z : 0.70   # 睜眼前移
    jaw_Z: 0.30   # 輕微開口後縮（high 強度才明顯）
```

---

### sadness（悲傷，靜態未哭）
> 眉頭上揚（內側）下壓，嘴角下拉，眼睛略瞇帶濕潤感，無哭泣動作

```yaml
sadness:
  min_conf: est
  low:
    bf  : 0.30
    mcd : 0.20
    esq : 0.10
  medium:
    bf  : 0.55
    mcd : 0.40
    esq : 0.20
    brow_tension: 0.20
  high:
    bf  : 0.80
    mcd : 0.60
    esq : 0.35
    brow_tension: 0.35
    lip_pressure: 0.30
  Z:
    bf_Z: 0.45   # 眉頭下壓，悲傷時皺眉肌後縮程度中等
```

---

### disgust（厭惡）
> 鼻翼皺起、嘴角下拉、眼睛瞇起，上唇輕微上提，帶有「想遠離」的身體語言

```yaml
disgust:
  min_conf: low_est
  low:
    nf          : 0.25
    mcd         : 0.20
    lip_pressure: 0.25
    esq         : 0.10
  medium:
    nf          : 0.45
    mcd         : 0.40
    lip_pressure: 0.45
    esq         : 0.20
    brow_tension: 0.20
  high:
    nf          : 0.70
    mcd         : 0.60
    lip_pressure: 0.60
    esq         : 0.35
    brow_tension: 0.40
    jaw_tension : 0.25
  Z: none   # 鼻翼和嘴角主要是平面運動
```

---

### crying（哭泣）
> 悲傷動作 + 眼眶濕潤，眉頭下壓，下巴輕顫
> eye_wet 為描述性標記，無幾何 delta

```yaml
crying:
  min_conf: measured
  low:
    bf          : 0.40
    mcd         : 0.30
    esq         : 0.10
    brow_tension: 0.25
    eye_wet     : 0.40
  medium:
    bf          : 0.70
    mcd         : 0.55
    esq         : 0.25
    brow_tension: 0.45
    jaw_tension : 0.20
    jaw         : 0.10
    eye_wet     : 0.75
  high:
    bf          : 1.00
    mcd         : 0.85
    esq         : 0.40
    brow_tension: 0.65
    jaw_tension : 0.40
    jaw         : 0.20
    eye_wet     : 1.00
  Z:
    bf_Z : 0.60   # 眉頭深壓後縮，哭泣時最明顯
    jaw_Z: 0.20   # 下巴輕顫帶微後縮
```

---

## 【二、複合情緒】

### embarrassment（尷尬）
> 羞恥感輕微、帶焦慮，嘴角不確定地微動，眉頭輕蹙

```yaml
embarrassment:
  min_conf: low_est
  low:
    mcl         : 0.15
    esq         : 0.10
    brow_tension: 0.15
  medium:
    mcl         : 0.25
    esq         : 0.20
    brow_tension: 0.30
    mcd         : 0.10
  high:
    mcl         : 0.30
    esq         : 0.30
    brow_tension: 0.45
    mcd         : 0.20
    jaw_tension : 0.20
  Z:
    mcl_Z: 0.15   # 嘴角微前移（動作幅度小，Z 分量很小）
```

---

### shame（羞恥）
> 目光迴避感，嘴角下拉，眉頭下壓，整體臉部收縮感

```yaml
shame:
  min_conf: low_est
  low:
    mcd         : 0.20
    bf          : 0.25
    esq         : 0.15
  medium:
    mcd         : 0.35
    bf          : 0.45
    esq         : 0.25
    lip_pressure: 0.20
  high:
    mcd         : 0.55
    bf          : 0.65
    esq         : 0.40
    lip_pressure: 0.35
    jaw_tension : 0.25
  Z:
    bf_Z: 0.40   # 眉頭下壓後縮，羞恥時有明顯的眉間後縮
```

---

### guilt（內疚）
> 比 shame 更內向，嘴角輕微下拉，眉間輕壓，眼神向下

```yaml
guilt:
  min_conf: low_est
  low:
    mcd         : 0.15
    brow_tension: 0.20
    esq         : 0.10
  medium:
    mcd         : 0.30
    brow_tension: 0.35
    esq         : 0.20
    lip_pressure: 0.15
  high:
    mcd         : 0.45
    brow_tension: 0.50
    esq         : 0.30
    lip_pressure: 0.30
    jaw_tension : 0.20
  Z: none
```

---

### pride（驕傲）
> 嘴角輕揚、眉間放鬆（負值），有輕微昂揚感，不同於輕蔑

```yaml
pride:
  min_conf: est
  low:
    mcl         : 0.20
    esq         : 0.05
    brow_tension: -0.10    # 眉間放鬆
  medium:
    mcl         : 0.35
    cp          : 0.15
    brow_tension: -0.15
  high:
    mcl         : 0.50
    cp          : 0.25
    brow_tension: -0.20
    esq         : 0.10
  Z:
    mcl_Z: 0.25   # 嘴角輕微前移，驕傲感帶輕微前凸
    cp_Z : 0.20   # 顴部輕微前凸
```

---

### relief（如釋重負）
> fear/tension 消退後的鬆弛，嘴角輕揚，眉間和下頜都放鬆

```yaml
relief:
  min_conf: est
  low:
    mcl         : 0.20
    brow_tension: -0.10
    jaw_tension : -0.20    # 負值 = 放鬆
  medium:
    mcl         : 0.35
    brow_tension: -0.20
    jaw_tension : -0.40
    jaw         : 0.05
  high:
    mcl         : 0.45
    brow_tension: -0.30
    jaw_tension : -0.60
    jaw         : 0.10
    br          : 0.15
  Z:
    mcl_Z: 0.25   # 嘴角輕微前移
    br_Z : 0.20   # 揚眉前凸（輕微）
    jaw_Z: 0.10   # 下頜放鬆後的輕微後移
```

---

### gratitude（感激）
> 溫暖的笑意，眼睛柔和，比 smile_subtle 帶更多情感深度

```yaml
gratitude:
  min_conf: est
  low:
    mcl         : 0.30
    esq         : 0.10
    brow_tension: 0.05
  medium:
    mcl         : 0.50
    esq         : 0.20
    cp          : 0.20
  high:
    mcl         : 0.65
    esq         : 0.30
    cp          : 0.35
    br          : 0.10
  Z:
    mcl_Z: 0.30   # 嘴角前移，溫暖的笑意帶立體感
    cp_Z : 0.25   # 顴部輕微前凸
```

---

### longing（渴望/思念）
> 眼神飄遠，眉頭輕輕蹙起，嘴角微垂，整體呈現「凝視遠方」感

```yaml
longing:
  min_conf: low_est
  low:
    esq         : 0.10
    mcd         : 0.10
    brow_tension: 0.10
  medium:
    esq         : 0.20
    mcd         : 0.20
    brow_tension: 0.20
    lip_pressure: 0.10
  high:
    esq         : 0.35
    mcd         : 0.30
    brow_tension: 0.30
    lip_pressure: 0.25
    bf          : 0.15
  Z: none
```

---

### nostalgia（懷念）
> 悲傷與喜悅同時存在的甜蜜感，嘴角輕揚但眉頭帶一絲蹙起

```yaml
nostalgia:
  min_conf: low_est
  low:
    mcl         : 0.15
    esq         : 0.10
    mcd         : 0.05
  medium:
    mcl         : 0.20
    esq         : 0.15
    mcd         : 0.10
    brow_tension: 0.10
  high:
    mcl         : 0.25
    esq         : 0.20
    mcd         : 0.15
    brow_tension: 0.20
    bf          : 0.10
  Z:
    mcl_Z: 0.10   # 極輕微的嘴角前移
```

---

### envy（嫉妒）
> 眼神斜視感，眉頭輕壓，嘴唇緊，帶有「不甘心」的收斂感

```yaml
envy:
  min_conf: low_est
  low:
    esq         : 0.15
    brow_tension: 0.20
    lip_pressure: 0.15
  medium:
    esq         : 0.25
    brow_tension: 0.35
    lip_pressure: 0.25
    mcd         : 0.10
  high:
    esq         : 0.40
    brow_tension: 0.50
    lip_pressure: 0.40
    mcd         : 0.20
    jaw_tension : 0.20
  Z: none
```

---

### boredom（無聊）
> 整體低激活，眼睛微瞇，嘴角輕垂，眉毛放低，下巴略鬆弛

```yaml
boredom:
  min_conf: low_est
  low:
    esq         : 0.10
    mcd         : 0.05
    brow_tension: -0.05
  medium:
    esq         : 0.20
    mcd         : 0.10
    brow_tension: -0.10
    jaw         : 0.05
  high:
    esq         : 0.30
    mcd         : 0.15
    brow_tension: -0.15
    jaw         : 0.10
    br          : -0.10
  Z: none
```

---

### confusion（困惑）
> 眉頭不對稱（單側輕揚），眼睛瞇起，嘴角輕微下拉

```yaml
confusion:
  min_conf: low_est
  low:
    bf          : 0.20
    asym        : +0.30    # 單側眉微揚
    esq         : 0.10
  medium:
    bf          : 0.35
    asym        : +0.50
    esq         : 0.20
    mcd         : 0.10
  high:
    bf          : 0.55
    asym        : +0.70
    esq         : 0.30
    mcd         : 0.20
    jaw         : 0.10
  Z:
    bf_Z : 0.30   # 眉頭輕壓後縮
    jaw_Z: 0.20   # 困惑時輕微開口後縮
```

---

### determination（堅定）
> 意志態而非情緒態：唇緊閉，下頜緊繃，眉頭輕壓，眼神聚焦

```yaml
determination:
  min_conf: low_est
  low:
    lip_pressure: 0.35
    jaw_tension : 0.25
    brow_tension: 0.15
  medium:
    lip_pressure: 0.55
    jaw_tension : 0.45
    brow_tension: 0.25
    esq         : 0.10
  high:
    lip_pressure: 0.75
    jaw_tension : 0.65
    brow_tension: 0.40
    esq         : 0.20
    mcd         : 0.10
  Z: none   # 主要是肌肉張力，無明顯三維移動
```

---

### hesitation（猶豫）
> 嘴角不對稱輕動，唇輕壓，眉頭帶一絲蹙起，整體表情在「說與不說」之間

```yaml
hesitation:
  min_conf: low_est
  low:
    asym        : +0.20
    lip_pressure: 0.15
    brow_tension: 0.10
  medium:
    asym        : +0.35
    lip_pressure: 0.25
    brow_tension: 0.20
    esq         : 0.10
  high:
    asym        : +0.50
    lip_pressure: 0.35
    brow_tension: 0.30
    esq         : 0.20
    mcd         : 0.10
  Z: none
```

---

### anxiety（焦慮）
> 持續低強度的 fear，眉頭輕壓，唇緊，下頜緊繃，無明顯的眼大或眉揚

```yaml
anxiety:
  min_conf: low_est
  low:
    brow_tension: 0.30
    lip_pressure: 0.20
    jaw_tension : 0.20
  medium:
    brow_tension: 0.50
    lip_pressure: 0.35
    jaw_tension : 0.40
    esq         : 0.10
  high:
    brow_tension: 0.70
    lip_pressure: 0.55
    jaw_tension : 0.60
    esq         : 0.20
    mcd         : 0.10
    nf          : 0.10
  Z: none
```

---

### nervousness（緊張）
> 社會評估情境下的 fear，比 anxiety 更帶社交成分，唇輕壓，眉頭帶微蹙

```yaml
nervousness:
  min_conf: low_est
  low:
    lip_pressure: 0.20
    brow_tension: 0.15
    esq         : 0.05
  medium:
    lip_pressure: 0.35
    brow_tension: 0.30
    esq         : 0.15
    jaw_tension : 0.20
  high:
    lip_pressure: 0.50
    brow_tension: 0.45
    esq         : 0.25
    jaw_tension : 0.40
    mcd         : 0.10
  Z: none
```

---

### awe（敬畏）
> surprise + 正向崇敬：眼睛睜大、眉揚，但嘴角輕壓而非張開，有「不敢出聲」感

```yaml
awe:
  min_conf: est
  low:
    eo          : 0.40
    br          : 0.35
    jaw         : 0.10
  medium:
    eo          : 0.65
    br          : 0.60
    jaw         : 0.25
    lip_pressure: 0.10
  high:
    eo          : 0.90
    br          : 0.85
    jaw         : 0.45
    lip_pressure: 0.05
  Z:
    br_Z : 0.75   # 揚眉前凸，敬畏時眉弓明顯前凸
    eo_Z : 0.70   # 睜眼前移
    jaw_Z: 0.40   # 開口後縮
```

---

### wonder（讚嘆）
> 輕鬆版的 awe，眼睛睜大、眉揚，帶輕微笑意，比 awe 更溫暖

```yaml
wonder:
  min_conf: est
  low:
    eo          : 0.35
    br          : 0.30
    mcl         : 0.15
  medium:
    eo          : 0.55
    br          : 0.50
    mcl         : 0.25
    jaw         : 0.10
  high:
    eo          : 0.75
    br          : 0.70
    mcl         : 0.40
    jaw         : 0.20
    cp          : 0.15
  Z:
    br_Z : 0.60   # 揚眉前凸
    eo_Z : 0.60   # 睜眼前移
    mcl_Z: 0.20   # 嘴角輕微前移（帶笑意）
    jaw_Z: 0.30   # 輕微開口後縮
```

---

### curiosity（好奇）
> 眉毛輕揚（不對稱，單側更明顯），眼睛微瞇聚焦，嘴角輕揚

```yaml
curiosity:
  min_conf: low_est
  low:
    br          : 0.25
    esq         : 0.10
    asym        : +0.20
  medium:
    br          : 0.45
    esq         : 0.20
    asym        : +0.35
    mcl         : 0.10
  high:
    br          : 0.65
    esq         : 0.30
    asym        : +0.50
    mcl         : 0.20
    jaw         : 0.05
  Z:
    br_Z : 0.45   # 揚眉前凸（好奇時眉弓前凸）
```

---

### excitement（興奮）
> 高強度 joy + 新奇感，嘴角大幅上揚，眼睛睜大，顴部上推

```yaml
excitement:
  min_conf: measured
  low:
    mcl         : 0.45
    eo          : 0.30
    cp          : 0.25
  medium:
    mcl         : 0.65
    eo          : 0.45
    cp          : 0.40
    jaw         : 0.15
  high:
    mcl         : 0.85
    eo          : 0.65
    cp          : 0.60
    jaw         : 0.30
    br          : 0.25
  Z:
    mcl_Z: 0.70   # 嘴角大幅前移，興奮感的立體特徵
    cp_Z : 0.55   # 顴部前凸
    eo_Z : 0.50   # 睜眼前移
    jaw_Z: 0.35   # 開口後縮
    br_Z : 0.25   # 眉毛前凸
```

---

### anticipation（期待）
> 期待混合輕微緊張，嘴角輕揚，眼睛略睜，唇部輕壓

```yaml
anticipation:
  min_conf: est
  low:
    mcl         : 0.20
    eo          : 0.20
    lip_pressure: 0.10
  medium:
    mcl         : 0.35
    eo          : 0.35
    lip_pressure: 0.20
    esq         : 0.05
  high:
    mcl         : 0.50
    eo          : 0.50
    lip_pressure: 0.30
    esq         : 0.10
    br          : 0.15
  Z:
    mcl_Z: 0.20   # 嘴角輕微前移
    eo_Z : 0.25   # 睜眼輕微前移
```

---

### satisfaction（滿足）
> joy 峰值後的平息狀態，嘴角輕揚，眉間放鬆，顴部輕推

```yaml
satisfaction:
  min_conf: est
  low:
    mcl         : 0.25
    esq         : 0.10
    brow_tension: -0.10
  medium:
    mcl         : 0.40
    esq         : 0.20
    brow_tension: -0.15
    cp          : 0.10
  high:
    mcl         : 0.55
    esq         : 0.30
    brow_tension: -0.20
    cp          : 0.20
  Z:
    mcl_Z: 0.25   # 嘴角前移，滿足感的輕微前凸
    cp_Z : 0.15   # 顴部輕微前凸
```

---

### disappointment（失望）
> 期待落空，嘴角下拉，眉頭輕壓，眼睛微瞇，比 sadness 更帶「氣餒」感

```yaml
disappointment:
  min_conf: low_est
  low:
    mcd         : 0.25
    brow_tension: 0.15
    esq         : 0.10
  medium:
    mcd         : 0.45
    brow_tension: 0.30
    esq         : 0.20
    bf          : 0.15
  high:
    mcd         : 0.65
    brow_tension: 0.45
    esq         : 0.30
    bf          : 0.30
    lip_pressure: 0.20
  Z:
    bf_Z: 0.30   # 眉頭輕壓後縮
```

---

### frustration（沮喪/挫折）
> 受阻的憤怒，眉頭壓，嘴角下拉，下頜緊繃，鼻翼微張

```yaml
frustration:
  min_conf: low_est
  low:
    mcd         : 0.20
    brow_tension: 0.25
    jaw_tension : 0.20
  medium:
    mcd         : 0.35
    brow_tension: 0.45
    jaw_tension : 0.40
    lip_pressure: 0.20
  high:
    mcd         : 0.50
    brow_tension: 0.65
    jaw_tension : 0.60
    lip_pressure: 0.35
    nf          : 0.15
  Z: none
```

---

### resignation（認命/無奈）
> 慢性悲傷後的放棄感，眉頭輕壓，嘴角微垂，下頜放鬆，整體「垮下來」感

```yaml
resignation:
  min_conf: low_est
  low:
    mcd         : 0.15
    esq         : 0.10
    brow_tension: 0.10
  medium:
    mcd         : 0.25
    esq         : 0.20
    brow_tension: 0.20
    jaw_tension : -0.15
  high:
    mcd         : 0.40
    esq         : 0.30
    brow_tension: 0.30
    jaw_tension : -0.25
    jaw         : 0.05
  Z: none
```

---

### melancholy（憂鬱/哀愁）
> 低強度慢性悲傷，比 sadness 更靜、更深，眉頭輕壓，嘴角微垂，眼神空洞

```yaml
melancholy:
  min_conf: low_est
  low:
    mcd         : 0.15
    bf          : 0.20
    esq         : 0.15
    brow_tension: 0.10
  medium:
    mcd         : 0.25
    bf          : 0.35
    esq         : 0.25
    brow_tension: 0.20
  high:
    mcd         : 0.40
    bf          : 0.55
    esq         : 0.35
    brow_tension: 0.35
    lip_pressure: 0.15
  Z:
    bf_Z: 0.35   # 眉頭輕壓後縮，憂鬱的壓抑感
```

---

### tenderness（溫柔）
> joy × attachment，嘴角輕揚帶溫柔感，眼睛略瞇，眉間放鬆，顴部輕推

```yaml
tenderness:
  min_conf: est
  low:
    mcl         : 0.20
    esq         : 0.15
    brow_tension: -0.10
  medium:
    mcl         : 0.35
    esq         : 0.25
    brow_tension: -0.15
    cp          : 0.10
  high:
    mcl         : 0.50
    esq         : 0.35
    brow_tension: -0.20
    cp          : 0.20
  Z:
    mcl_Z: 0.20   # 嘴角輕微前移，溫柔感帶輕微立體
    cp_Z : 0.15   # 顴部極輕微前凸
```

---

### adoration（崇拜）
> joy + 崇敬感，嘴角揚，眼睛睜大柔和，眉間放鬆，顴部輕推

```yaml
adoration:
  min_conf: est
  low:
    mcl         : 0.25
    eo          : 0.25
    esq         : 0.10
  medium:
    mcl         : 0.40
    eo          : 0.40
    esq         : 0.20
    brow_tension: -0.10
  high:
    mcl         : 0.55
    eo          : 0.60
    esq         : 0.30
    brow_tension: -0.15
    cp          : 0.15
  Z:
    mcl_Z: 0.25   # 嘴角前移
    eo_Z : 0.35   # 睜眼前移，崇拜時眼睛更開
    cp_Z : 0.20   # 顴部輕微前凸
```

---

### suspicion（懷疑）
> 眼睛斜瞇（不對稱），眉頭輕壓，唇輕壓，帶「在評估對方」感

```yaml
suspicion:
  min_conf: low_est
  low:
    esq         : 0.20
    brow_tension: 0.20
    asym        : +0.25
  medium:
    esq         : 0.35
    brow_tension: 0.35
    asym        : +0.45
    lip_pressure: 0.15
  high:
    esq         : 0.50
    brow_tension: 0.55
    asym        : +0.60
    lip_pressure: 0.30
    mcd         : 0.10
  Z: none
```

---

### wariness（戒備）
> 慢性低強度 fear，眼睛微瞇，眉頭輕壓，唇輕壓，下頜微緊

```yaml
wariness:
  min_conf: low_est
  low:
    esq         : 0.15
    brow_tension: 0.20
    lip_pressure: 0.10
  medium:
    esq         : 0.25
    brow_tension: 0.35
    lip_pressure: 0.20
    jaw_tension : 0.15
  high:
    esq         : 0.40
    brow_tension: 0.50
    lip_pressure: 0.35
    jaw_tension : 0.30
    mcd         : 0.10
  Z: none
```

---

### calculating（算計中）
> 幾乎是認知態，眼睛斜瞇（不對稱），眉頭輕壓，唇輕壓，嘴角微揚（算計感）

```yaml
calculating:
  min_conf: low_est
  low:
    esq         : 0.20
    brow_tension: 0.15
    asym        : +0.20
  medium:
    esq         : 0.35
    brow_tension: 0.25
    asym        : +0.35
    lip_pressure: 0.15
  high:
    esq         : 0.50
    brow_tension: 0.35
    asym        : +0.50
    lip_pressure: 0.30
    mcl         : 0.10
  Z:
    mcl_Z: 0.10   # 嘴角極輕微前移（算計時微微揚起）
```

---

## 【三、社交性/表演性表情】

### polite_smile（禮貌性微笑）
> Duchenne = 0：嘴角動但眼周不參與，社交場合的「職業笑容」

```yaml
polite_smile:
  min_conf: est
  low:
    mcl         : 0.25
  medium:
    mcl         : 0.40
    mwd         : 0.10
  high:
    mcl         : 0.55
    mwd         : 0.20
    lip_pressure: 0.10
  Z:
    mcl_Z: 0.20   # 嘴角前移，但幅度較自然笑小（社交笑容較平面）
```

---

### forced_smile（強顏歡笑）
> 嘴角上揚但伴隨下頜張力，帶「努力撐著笑」的肌肉衝突感

```yaml
forced_smile:
  min_conf: est
  low:
    mcl         : 0.30
    jaw_tension : 0.20
    lip_pressure: 0.15
  medium:
    mcl         : 0.50
    jaw_tension : 0.40
    lip_pressure: 0.30
    brow_tension: 0.15
  high:
    mcl         : 0.70
    jaw_tension : 0.60
    lip_pressure: 0.50
    brow_tension: 0.25
  Z:
    mcl_Z: 0.15   # 嘴角勉強前移，因下頜張力拮抗，Z 分量受壓制
```

---

### bitter_smile（苦笑）
> 嘴角同時有上揚和下拉的衝突，眼睛微瞇，帶「無奈之笑」感

```yaml
bitter_smile:
  min_conf: est
  low:
    mcl         : 0.20
    mcd         : 0.10
    esq         : 0.10
  medium:
    mcl         : 0.30
    mcd         : 0.20
    esq         : 0.20
    brow_tension: 0.15
  high:
    mcl         : 0.40
    mcd         : 0.30
    esq         : 0.30
    brow_tension: 0.25
    lip_pressure: 0.20
  Z:
    mcl_Z: 0.15   # 嘴角前移量小，苦笑的立體感壓抑
```

---

### wry_smile（自嘲式苦笑）
> 單側嘴角揚（不對稱），眼睛微瞇，帶「我知道自己很可笑」的自我意識

```yaml
wry_smile:
  min_conf: est
  low:
    mcl         : 0.25
    asym        : +0.40
    esq         : 0.10
  medium:
    mcl         : 0.35
    asym        : +0.60
    esq         : 0.20
    mcd         : 0.10
  high:
    mcl         : 0.45
    asym        : +0.80
    esq         : 0.30
    mcd         : 0.20
    brow_tension: 0.15
  Z:
    mcl_Z: 0.20   # 單側嘴角前移（不對稱，配合 asym）
```

---

### hollow_laugh（乾笑）
> 嘴角上揚但伴隨下頜張力，「哈哈哈」但眼睛沒有參與，內在空洞

```yaml
hollow_laugh:
  min_conf: measured
  low:
    mcl         : 0.40
    jaw         : 0.15
    jaw_tension : 0.25
  medium:
    mcl         : 0.55
    jaw         : 0.25
    jaw_tension : 0.45
    brow_tension: 0.10
  high:
    mcl         : 0.70
    jaw         : 0.35
    jaw_tension : 0.65
    brow_tension: 0.20
    lip_pressure: 0.15
  Z:
    mcl_Z: 0.30   # 嘴角前移，但 jaw_tension 抑制了 cp 的前凸
    jaw_Z: 0.50   # 開口後縮（乾笑時下頜運動更多）
```

---

### nervous_laugh（尷尬笑）
> 焦慮下的防禦性笑，嘴角揚但眉頭蹙，帶「不知所措」感

```yaml
nervous_laugh:
  min_conf: measured
  low:
    mcl         : 0.35
    jaw         : 0.10
    brow_tension: 0.15
  medium:
    mcl         : 0.50
    jaw         : 0.20
    brow_tension: 0.25
    esq         : 0.10
  high:
    mcl         : 0.65
    jaw         : 0.30
    brow_tension: 0.40
    esq         : 0.20
    lip_pressure: 0.10
  Z:
    mcl_Z: 0.25   # 嘴角前移（帶焦慮感，幅度中等）
    jaw_Z: 0.30   # 開口後縮
```

---

### smug（自鳴得意）
> contempt + 滿足：單側嘴角揚，眼睛微瞇，帶「我就知道」的優越感

```yaml
smug:
  min_conf: low_est
  low:
    mcl         : 0.20
    asym        : +0.30
    esq         : 0.10
  medium:
    mcl         : 0.30
    asym        : +0.50
    esq         : 0.20
    brow_tension: -0.10
  high:
    mcl         : 0.40
    asym        : +0.70
    esq         : 0.30
    brow_tension: -0.15
    cp          : 0.10
  Z:
    mcl_Z: 0.15   # 嘴角輕微前移（自得意滿的收斂）
    cp_Z : 0.10   # 顴部極輕前凸
```

---

### arrogance（傲慢）
> contempt 為主，帶支配感：眼睛半瞇俯視，嘴角輕下拉，眉間放鬆（不屑蹙眉）

```yaml
arrogance:
  min_conf: low_est
  low:
    mcl         : 0.10
    brow_tension: -0.15
    esq         : 0.15
    mcd         : 0.05
  medium:
    mcl         : 0.15
    brow_tension: -0.25
    esq         : 0.25
    mcd         : 0.10
  high:
    mcl         : 0.20
    brow_tension: -0.35
    esq         : 0.35
    mcd         : 0.20
    asym        : +0.30
  Z: none
```

---

### mockery（嘲諷）
> 帶笑的輕蔑，單側嘴角揚帶不對稱，眼睛瞇，比 contempt 多了嘲弄的快感

```yaml
mockery:
  min_conf: low_est
  low:
    mcl         : 0.20
    asym        : +0.45
    esq         : 0.15
    mcd         : 0.10
  medium:
    mcl         : 0.30
    asym        : +0.65
    esq         : 0.25
    mcd         : 0.20
    brow_tension: 0.10
  high:
    mcl         : 0.40
    asym        : +0.85
    esq         : 0.35
    mcd         : 0.30
    brow_tension: 0.20
  Z:
    mcl_Z: 0.15   # 嘴角輕微前移（嘲諷帶輕微前凸）
```

---

### playful（調皮）
> 開放愉快狀態，嘴角揚帶不對稱，眉毛輕揚，帶「我在開玩笑」的活潑感

```yaml
playful:
  min_conf: est
  low:
    mcl         : 0.35
    asym        : +0.25
    br          : 0.20
  medium:
    mcl         : 0.50
    asym        : +0.40
    br          : 0.35
    esq         : 0.10
  high:
    mcl         : 0.65
    asym        : +0.55
    br          : 0.50
    esq         : 0.20
    jaw         : 0.10
  Z:
    mcl_Z: 0.35   # 嘴角前移，調皮感帶明顯立體
    br_Z : 0.35   # 眉毛前凸
```

---

### speaking（說話中）
> 生理動作，非情緒：下巴張合，嘴角外張，依音節幅度調整強度

```yaml
speaking:
  min_conf: measured
  low:
    jaw         : 0.20
    mwd         : 0.15
  medium:
    jaw         : 0.45
    mwd         : 0.30
  high:
    jaw         : 0.75
    mwd         : 0.50
  Z:
    jaw_Z: 0.50   # 說話時下頜弧形後縮，Z 分量為語音動作的自然結果
```

---

## 【四、過渡性/壓抑狀態】

> 此類表情涉及「情緒 × 壓制」的衝突動力學。
> 特徵是肌肉同時存在相互拮抗的張力，視覺上呈現「努力控制」的不自然感。

---

### suppressing_tears（強忍眼淚）
> 高悲傷 + 高壓制嘗試，眉頭下壓，唇緊閉，下頜緊繃，眼眶濕潤

```yaml
suppressing_tears:
  min_conf: est
  low:
    bf          : 0.25
    esq         : 0.10
    lip_pressure: 0.25
    jaw_tension : 0.20
    eye_wet     : 0.30
  medium:
    bf          : 0.45
    esq         : 0.20
    lip_pressure: 0.45
    jaw_tension : 0.40
    eye_wet     : 0.60
  high:
    bf          : 0.65
    esq         : 0.30
    lip_pressure: 0.65
    jaw_tension : 0.60
    mcd         : 0.15
    eye_wet     : 0.85
  Z:
    bf_Z: 0.55   # 眉頭深壓後縮，強忍眼淚時最明顯
```

---

### suppressing_laugh（強忍笑意）
> 高喜悅 + 強制壓制（場合不允許），嘴唇緊閉但臉頰帶笑肌張力，眼睛瞇

```yaml
suppressing_laugh:
  min_conf: est
  low:
    lip_pressure: 0.40
    esq         : 0.15
    jaw_tension : 0.25
  medium:
    lip_pressure: 0.60
    esq         : 0.25
    jaw_tension : 0.45
    mcl         : 0.10
  high:
    lip_pressure: 0.80
    esq         : 0.35
    jaw_tension : 0.65
    mcl         : 0.20
    cp          : 0.15
  Z:
    mcl_Z: 0.10   # 嘴角被壓制，Z 分量極小（唇壓拮抗）
    cp_Z : 0.10   # 顴部張力存在但被壓制
```

---

### choking_up（哽咽）
> 悲傷壓制中的生理反應，眉頭下壓，下頜緊繃，嘴角輕垂，喉嚨收緊感

```yaml
choking_up:
  min_conf: est
  low:
    bf          : 0.35
    jaw_tension : 0.30
    mcd         : 0.15
    lip_pressure: 0.30
    eye_wet     : 0.40
  medium:
    bf          : 0.55
    jaw_tension : 0.55
    mcd         : 0.25
    lip_pressure: 0.50
    jaw         : 0.05
    eye_wet     : 0.65
  high:
    bf          : 0.75
    jaw_tension : 0.75
    mcd         : 0.40
    lip_pressure: 0.65
    jaw         : 0.10
    eye_wet     : 0.85
  Z:
    bf_Z : 0.55   # 眉頭深壓後縮
    jaw_Z: 0.15   # 下頜輕微顫動後縮
```

---

### crying_while_smiling（破涕為笑）
> sadness + smile 的複合疊加，眉頭下壓帶笑意，眼眶濕潤但嘴角上揚

```yaml
crying_while_smiling:
  min_conf: measured
  low:
    mcl         : 0.25
    bf          : 0.25
    mcd         : 0.10
    eye_wet     : 0.35
  medium:
    mcl         : 0.40
    bf          : 0.40
    mcd         : 0.15
    esq         : 0.10
    eye_wet     : 0.60
  high:
    mcl         : 0.55
    bf          : 0.55
    mcd         : 0.20
    esq         : 0.15
    cp          : 0.15
    eye_wet     : 0.80
  Z:
    mcl_Z: 0.25   # 嘴角前移（笑的成分）
    bf_Z : 0.40   # 眉頭後縮（哭的成分）
    cp_Z : 0.15   # 顴部輕微前凸（笑的成分）
```

---

### shock（震驚）
> 強於 surprise，含恐懼成分：眼睛最大幅度睜開，眉揚，下巴張，帶呆滯感

```yaml
shock:
  min_conf: measured
  low:
    eo          : 0.60
    br          : 0.55
    jaw         : 0.25
    lip_pressure: 0.10
  medium:
    eo          : 0.80
    br          : 0.75
    jaw         : 0.45
    lip_pressure: 0.05
    brow_tension: 0.15
  high:
    eo          : 1.00
    br          : 1.00
    jaw         : 0.70
    brow_tension: 0.30
    jaw_tension : 0.20
  Z:
    br_Z : 1.00   # 揚眉最大前凸，震驚的標誌性立體動作
    eo_Z : 1.00   # 睜眼最大前移
    jaw_Z: 0.70   # 大幅開口後縮
```

---

### dissociation（神遊/空洞）
> 情緒系統接近關閉，近乎零輸出，眼神失焦，下頜放鬆，接近「空氣臉」

```yaml
dissociation:
  min_conf: low_est
  low:
    esq         : 0.05
    brow_tension: -0.05
  medium:
    esq         : 0.10
    brow_tension: -0.10
    jaw_tension : -0.20
  high:
    esq         : 0.15
    brow_tension: -0.15
    jaw_tension : -0.35
    jaw         : 0.05
  Z: none   # 近乎零輸出，無明顯三維動作
```

---

## 【五、生理狀態】

> 此類表情由生理狀態驅動，非情緒通道。
> 建議在系統架構中獨立為 PhysicalState 層輸入，不走情緒通道。

---

### pain（痛苦，生理）
> 眉頭深壓，眼睛用力瞇，下頜緊繃，鼻翼微張，帶「咬牙撐著」感

```yaml
pain:
  min_conf: measured
  low:
    bf          : 0.45
    brow_tension: 0.40
    esq         : 0.25
    jaw_tension : 0.30
  medium:
    bf          : 0.70
    brow_tension: 0.65
    esq         : 0.40
    jaw_tension : 0.55
    mcd         : 0.20
  high:
    bf          : 0.95
    brow_tension: 0.90
    esq         : 0.55
    jaw_tension : 0.80
    mcd         : 0.35
    nf          : 0.20
  Z:
    bf_Z: 0.90   # 眉頭深壓後縮，痛苦時眉間後縮最強烈
```

---

### exhaustion（極度疲憊）
> 眼睛半瞇，眉頭放鬆下垂，嘴角輕微下拉，下巴略張，整體「撐不住了」感

```yaml
exhaustion:
  min_conf: est
  low:
    esq         : 0.15
    brow_tension: -0.05
    mcd         : 0.05
  medium:
    esq         : 0.30
    brow_tension: -0.10
    mcd         : 0.10
    jaw         : 0.05
  high:
    esq         : 0.50
    brow_tension: -0.15
    mcd         : 0.20
    jaw         : 0.10
    lip_pressure: -0.20
  Z: none
```

---

### nausea（噁心）
> 鼻翼皺起，嘴角下拉，眼睛瞇，眉頭輕壓，帶「反胃」的生理反應感

```yaml
nausea:
  min_conf: low_est
  low:
    nf          : 0.20
    mcd         : 0.15
    esq         : 0.10
  medium:
    nf          : 0.40
    mcd         : 0.30
    esq         : 0.20
    brow_tension: 0.15
  high:
    nf          : 0.60
    mcd         : 0.45
    esq         : 0.30
    brow_tension: 0.25
    jaw_tension : 0.20
  Z: none
```

---

### drowsy（困倦）
> 眼睛沉重下垂，眉頭輕微放鬆，嘴角輕垂，比 exhaustion 更有「快睡著」感

```yaml
drowsy:
  min_conf: est
  low:
    esq         : 0.20
    brow_tension: -0.10
  medium:
    esq         : 0.40
    brow_tension: -0.15
    mcd         : 0.05
  high:
    esq         : 0.65
    brow_tension: -0.20
    mcd         : 0.10
    jaw         : 0.05
  Z: none
```

---

### drunk（醉意）
> 眼神散焦，嘴角輕揚帶不對稱，眼睛微瞇，表情略顯鬆弛

```yaml
drunk:
  min_conf: measured
  low:
    mcl         : 0.20
    esq         : 0.10
    asym        : +0.20
  medium:
    mcl         : 0.30
    esq         : 0.25
    asym        : +0.35
    jaw         : 0.10
  high:
    mcl         : 0.35
    esq         : 0.40
    asym        : +0.50
    jaw         : 0.20
    brow_tension: -0.15
  Z:
    mcl_Z: 0.15   # 嘴角輕微前移（醉意帶鬆弛前凸）
    jaw_Z: 0.20   # 下巴輕微後縮（醉酒鬆弛）
```

---

### yawning（打哈欠）
> 生理反射：下巴大幅張開，嘴角大幅外張，眼睛瞇（反射性流淚），眉毛輕揚

```yaml
yawning:
  min_conf: measured
  low:
    jaw         : 0.55
    mwd         : 0.40
    esq         : 0.20
    br          : 0.15
  medium:
    jaw         : 0.75
    mwd         : 0.60
    esq         : 0.35
    br          : 0.25
    jw          : 0.30
  high:
    jaw         : 1.00
    mwd         : 0.85
    esq         : 0.50
    br          : 0.35
    jw          : 0.55
  Z:
    jaw_Z: 1.00   # 打哈欠時下頜最大後縮，Z 分量最大
    br_Z : 0.30   # 眉毛輕揚前凸（反射動作）
```

---

## 【統計總覽】

| 類別 | 數量 | 有 Z 分量 | Z: none |
|------|------|-----------|---------|
| 基礎情緒 | 11 | 9 | 2（serious, disgust）|
| 複合情緒 | 30 | 16 | 14 |
| 社交/表演性 | 11 | 9 | 2（arrogance, mockery→mcl）|
| 過渡/壓抑狀態 | 6 | 5 | 1（dissociation）|
| 生理狀態 | 6 | 3 | 3（exhaustion, nausea, drowsy）|
| **合計** | **64** | **43** | **21** |

**Z 分量分佈（43 個有 Z 的表情）：**
- jaw_Z（後縮）出現：17 個表情
- cp_Z（前凸）出現：16 個表情
- mcl_Z（前移）出現：26 個表情
- br_Z（前凸）出現：11 個表情
- bf_Z（後縮）出現：10 個表情
- eo_Z（前移）出現：8 個表情
| 生理狀態 | 6 | 0 | 6 |
| **合計** | **64** | **7** | **57** |

---

## 【擴充說明（給設計者）】

新增表情時，遵循以下規範：

```
1. ratio 欄位只能使用上方「比值欄位對照表」中的欄位名稱
2. 所有 ratio 值 0.0–1.0，不超過 1.0
3. 負值僅允許用於軟組織欄位（brow_tension / jaw_tension / lip_pressure）
   表示「比 neutral 更放鬆」
4. 未列出的欄位 = 0.0（不需要寫出）
5. 每個強度級別（low/medium/high）應呈現明顯的漸進感
6. 加入說明行（# 描述）解釋該表情的肌肉特徵
7. [v1.7.0] 每個表情必須包含 Z: 區塊
   - 有三維動作（jaw/cp/mcl/bf/br/eo）→ 列出對應 Z_ratio（0.0–1.0）
   - 無三維動作 → 標記 Z: none
   - Z_ratio 代表「該肌肉 Z 分量的強度相對於 ML_Z_derived 上限」
   - Z_ratio 與 XY ratio 獨立，可不同值
```

---

```
模組    : AIFS ExprLib v1.7.1
對應主體: AIFS v1.7.0（幾何層）
狀態    : 正式版本
表情數  : 64 個（表情庫封版，v1.7.0 補充 Z_ratio 三維動作分量）
conf    : low_est:28 | est:23 | measured:13（v1.7.1 新增）
Z 覆蓋  : 43 個有 Z 分量 / 21 個 Z:none / 總計 64 個
```

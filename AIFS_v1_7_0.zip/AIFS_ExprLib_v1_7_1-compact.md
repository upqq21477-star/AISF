# AIFS_ExprLib_v1_7_1-compact
# Expression Library — companion module for AIFS v1.7.0+
# Requires: AIFS_v1_7_0-compact.md (for ML_lock + ML_Z_derived values)
# Logic XY: delta_XY = ratio × ML_lock_value | ratio ∈ [0.0,1.0] | T4 auto-pass guaranteed
# Logic Z:  delta_Z  = Z_ratio × ML_Z_derived_value | Z_ratio ∈ [0.0,1.0]
#           Z_eff = person.G9_[pt].Z + delta_Z  ← person.G9 from profile; NOT a fixed value
# Soft fields (no ML): jaw_tension[-1~1] brow_tension[-1~1] lip_pressure[-1~1] eye_wet[0-1] asym[-1~1]
# Negative soft = more relaxed than neutral
# Z fields: jaw_Z(Z-) cp_Z(Z+) mcl_Z(Z+) bf_Z(Z-) br_Z(Z+) eo_Z(Z+) | "Z:none" = planar only
#
# [min_conf] per-expression minimum ML confidence required before applying:
#   low_est  : soft-tissue / tension dominant; near-neutral; safe with low_est ML
#   est      : moderate muscle movement; requires basic ML calibration
#   measured : jaw opening / strong expression; requires real expression photo data
#   ⚠️ do not apply if person.ML_conf < min_conf → mark output as identity_confidence:low

---

## [FIELDS] ratio→ML mapping
mcl→ML_mcl | mcd→ML_mcd | mwd→ML_mwd | jaw→ML_jaw | esq→ML_esq | eo→ML_eo | br→ML_br | bf→ML_bf | cp→ML_cp | nf→ML_nf | jw→ML_jw

## [Z_FIELDS] Z_ratio→ML_Z_derived mapping (v1.7.0)
jaw_Z→ML_jaw_Z(×0.25,Z−) | cp_Z→ML_cp_Z(×0.40,Z+) | mcl_Z→ML_mcl_Z(×0.25,Z+) | bf_Z→ML_bf_Z(×0.25,Z−) | br_Z→ML_br_Z(×0.20,Z+) | eo_Z→ML_eo_Z(×0.12,Z+)

---

## [CAT1] Basic Emotions (11)

smile_subtle:
  conf: est
  L: mcl=0.30 cp=0.20
  M: mcl=0.50 cp=0.35
  H: mcl=0.70 cp=0.50
  Z: mcl_Z=0.30 cp_Z=0.25

smile_open:
  conf: measured
  L: mcl=0.50 cp=0.40 jaw=0.15 esq=0.10
  M: mcl=0.70 cp=0.55 jaw=0.25 esq=0.20
  H: mcl=0.90 cp=0.70 jaw=0.40 esq=0.30
  Z: jaw_Z=0.60 cp_Z=0.70 mcl_Z=0.60

laugh:
  conf: measured
  L: mcl=0.60 cp=0.55 jaw=0.35 esq=0.25 nf=0.15 jw=0.20
  M: mcl=0.80 cp=0.75 jaw=0.55 esq=0.40 nf=0.25 jw=0.40
  H: mcl=1.00 cp=1.00 jaw=0.80 esq=0.60 nf=0.40 jw=0.70
  Z: jaw_Z=0.80 cp_Z=1.00 mcl_Z=1.00

surprise:
  conf: measured
  L: eo=0.40 br=0.35 jaw=0.15
  M: eo=0.65 br=0.60 jaw=0.35
  H: eo=1.00 br=1.00 jaw=0.60
  Z: jaw_Z=0.55 br_Z=0.80 eo_Z=0.80

serious:
  conf: low_est
  L: brow_tension=0.20 mcd=0.10
  M: brow_tension=0.35 mcd=0.20 lip_pressure=0.20
  H: brow_tension=0.55 mcd=0.35 lip_pressure=0.40
  Z: none

contempt:
  conf: low_est
  L: mcl=0.20 asym=+0.40
  M: mcl=0.35 esq=0.15 asym=+0.60
  H: mcl=0.50 esq=0.25 asym=+0.80
  Z: mcl_Z=0.20

anger:
  conf: est
  L: bf=0.35 brow_tension=0.35 jaw_tension=0.30 esq=0.20 lip_pressure=0.25
  M: bf=0.60 brow_tension=0.60 jaw_tension=0.55 esq=0.40 lip_pressure=0.45 nf=0.30
  H: bf=0.90 brow_tension=0.90 jaw_tension=0.80 esq=0.60 lip_pressure=0.65 nf=0.55 mcd=0.20
  Z: bf_Z=0.70

fear:
  conf: est
  L: eo=0.45 br=0.40 brow_tension=0.25 lip_pressure=0.20
  M: eo=0.70 br=0.65 brow_tension=0.45 lip_pressure=0.35 jaw=0.10
  H: eo=1.00 br=0.90 brow_tension=0.65 lip_pressure=0.55 jaw=0.25 jaw_tension=0.40
  Z: br_Z=0.70 eo_Z=0.70 jaw_Z=0.30

sadness:
  conf: est
  L: bf=0.30 mcd=0.20 esq=0.10
  M: bf=0.55 mcd=0.40 esq=0.20 brow_tension=0.20
  H: bf=0.80 mcd=0.60 esq=0.35 brow_tension=0.35 lip_pressure=0.30
  Z: bf_Z=0.45

disgust:
  conf: low_est
  L: nf=0.25 mcd=0.20 lip_pressure=0.25 esq=0.10
  M: nf=0.45 mcd=0.40 lip_pressure=0.45 esq=0.20 brow_tension=0.20
  H: nf=0.70 mcd=0.60 lip_pressure=0.60 esq=0.35 brow_tension=0.40 jaw_tension=0.25
  Z: none

crying:
  conf: measured
  L: bf=0.40 mcd=0.30 esq=0.10 brow_tension=0.25 eye_wet=0.40
  M: bf=0.70 mcd=0.55 esq=0.25 brow_tension=0.45 jaw_tension=0.20 jaw=0.10 eye_wet=0.75
  H: bf=1.00 mcd=0.85 esq=0.40 brow_tension=0.65 jaw_tension=0.40 jaw=0.20 eye_wet=1.00
  Z: bf_Z=0.60 jaw_Z=0.20

---

## [CAT2] Complex Emotions (28)

embarrassment:
  conf: low_est
  L: mcl=0.15 esq=0.10 brow_tension=0.15
  M: mcl=0.25 esq=0.20 brow_tension=0.30 mcd=0.10
  H: mcl=0.30 esq=0.30 brow_tension=0.45 mcd=0.20 jaw_tension=0.20
  Z: mcl_Z=0.15

shame:
  conf: low_est
  L: mcd=0.20 bf=0.25 esq=0.15
  M: mcd=0.35 bf=0.45 esq=0.25 lip_pressure=0.20
  H: mcd=0.55 bf=0.65 esq=0.40 lip_pressure=0.35 jaw_tension=0.25
  Z: bf_Z=0.40

guilt:
  conf: low_est
  L: mcd=0.15 brow_tension=0.20 esq=0.10
  M: mcd=0.30 brow_tension=0.35 esq=0.20 lip_pressure=0.15
  H: mcd=0.45 brow_tension=0.50 esq=0.30 lip_pressure=0.30 jaw_tension=0.20
  Z: none

pride:
  conf: est
  L: mcl=0.20 esq=0.05 brow_tension=-0.10
  M: mcl=0.35 cp=0.15 brow_tension=-0.15
  H: mcl=0.50 cp=0.25 brow_tension=-0.20 esq=0.10
  Z: mcl_Z=0.25 cp_Z=0.20

relief:
  conf: est
  L: mcl=0.20 brow_tension=-0.10 jaw_tension=-0.20
  M: mcl=0.35 brow_tension=-0.20 jaw_tension=-0.40 jaw=0.05
  H: mcl=0.45 brow_tension=-0.30 jaw_tension=-0.60 jaw=0.10 br=0.15
  Z: mcl_Z=0.25 br_Z=0.20 jaw_Z=0.10

gratitude:
  conf: est
  L: mcl=0.30 esq=0.10 brow_tension=0.05
  M: mcl=0.50 esq=0.20 cp=0.20
  H: mcl=0.65 esq=0.30 cp=0.35 br=0.10
  Z: mcl_Z=0.30 cp_Z=0.25

longing:
  conf: low_est
  L: esq=0.10 mcd=0.10 brow_tension=0.10
  M: esq=0.20 mcd=0.20 brow_tension=0.20 lip_pressure=0.10
  H: esq=0.35 mcd=0.30 brow_tension=0.30 lip_pressure=0.25 bf=0.15
  Z: none

nostalgia:
  conf: low_est
  L: mcl=0.15 esq=0.10 mcd=0.05
  M: mcl=0.20 esq=0.15 mcd=0.10 brow_tension=0.10
  H: mcl=0.25 esq=0.20 mcd=0.15 brow_tension=0.20 bf=0.10
  Z: mcl_Z=0.10

envy:
  conf: low_est
  L: esq=0.15 brow_tension=0.20 lip_pressure=0.15
  M: esq=0.25 brow_tension=0.35 lip_pressure=0.25 mcd=0.10
  H: esq=0.40 brow_tension=0.50 lip_pressure=0.40 mcd=0.20 jaw_tension=0.20
  Z: none

boredom:
  conf: low_est
  L: esq=0.10 mcd=0.05 brow_tension=-0.05
  M: esq=0.20 mcd=0.10 brow_tension=-0.10 jaw=0.05
  H: esq=0.30 mcd=0.15 brow_tension=-0.15 jaw=0.10 br=-0.10
  Z: none

confusion:
  conf: low_est
  L: bf=0.20 asym=+0.30 esq=0.10
  M: bf=0.35 asym=+0.50 esq=0.20 mcd=0.10
  H: bf=0.55 asym=+0.70 esq=0.30 mcd=0.20 jaw=0.10
  Z: bf_Z=0.30 jaw_Z=0.20

determination:
  conf: low_est
  L: lip_pressure=0.35 jaw_tension=0.25 brow_tension=0.15
  M: lip_pressure=0.55 jaw_tension=0.45 brow_tension=0.25 esq=0.10
  H: lip_pressure=0.75 jaw_tension=0.65 brow_tension=0.40 esq=0.20 mcd=0.10
  Z: none

hesitation:
  conf: low_est
  L: asym=+0.20 lip_pressure=0.15 brow_tension=0.10
  M: asym=+0.35 lip_pressure=0.25 brow_tension=0.20 esq=0.10
  H: asym=+0.50 lip_pressure=0.35 brow_tension=0.30 esq=0.20 mcd=0.10
  Z: none

anxiety:
  conf: low_est
  L: brow_tension=0.30 lip_pressure=0.20 jaw_tension=0.20
  M: brow_tension=0.50 lip_pressure=0.35 jaw_tension=0.40 esq=0.10
  H: brow_tension=0.70 lip_pressure=0.55 jaw_tension=0.60 esq=0.20 mcd=0.10 nf=0.10
  Z: none

nervousness:
  conf: low_est
  L: lip_pressure=0.20 brow_tension=0.15 esq=0.05
  M: lip_pressure=0.35 brow_tension=0.30 esq=0.15 jaw_tension=0.20
  H: lip_pressure=0.50 brow_tension=0.45 esq=0.25 jaw_tension=0.40 mcd=0.10
  Z: none

awe:
  conf: est
  L: eo=0.40 br=0.35 jaw=0.10
  M: eo=0.65 br=0.60 jaw=0.25 lip_pressure=0.10
  H: eo=0.90 br=0.85 jaw=0.45 lip_pressure=0.05
  Z: br_Z=0.75 eo_Z=0.70 jaw_Z=0.40

wonder:
  conf: est
  L: eo=0.35 br=0.30 mcl=0.15
  M: eo=0.55 br=0.50 mcl=0.25 jaw=0.10
  H: eo=0.75 br=0.70 mcl=0.40 jaw=0.20 cp=0.15
  Z: br_Z=0.60 eo_Z=0.60 mcl_Z=0.20 jaw_Z=0.30

curiosity:
  conf: low_est
  L: br=0.25 esq=0.10 asym=+0.20
  M: br=0.45 esq=0.20 asym=+0.35 mcl=0.10
  H: br=0.65 esq=0.30 asym=+0.50 mcl=0.20 jaw=0.05
  Z: br_Z=0.45

excitement:
  conf: measured
  L: mcl=0.45 eo=0.30 cp=0.25
  M: mcl=0.65 eo=0.45 cp=0.40 jaw=0.15
  H: mcl=0.85 eo=0.65 cp=0.60 jaw=0.30 br=0.25
  Z: mcl_Z=0.70 cp_Z=0.55 eo_Z=0.50 jaw_Z=0.35 br_Z=0.25

anticipation:
  conf: est
  L: mcl=0.20 eo=0.20 lip_pressure=0.10
  M: mcl=0.35 eo=0.35 lip_pressure=0.20 esq=0.05
  H: mcl=0.50 eo=0.50 lip_pressure=0.30 esq=0.10 br=0.15
  Z: mcl_Z=0.20 eo_Z=0.25

satisfaction:
  conf: est
  L: mcl=0.25 esq=0.10 brow_tension=-0.10
  M: mcl=0.40 esq=0.20 brow_tension=-0.15 cp=0.10
  H: mcl=0.55 esq=0.30 brow_tension=-0.20 cp=0.20
  Z: mcl_Z=0.25 cp_Z=0.15

disappointment:
  conf: low_est
  L: mcd=0.25 brow_tension=0.15 esq=0.10
  M: mcd=0.45 brow_tension=0.30 esq=0.20 bf=0.15
  H: mcd=0.65 brow_tension=0.45 esq=0.30 bf=0.30 lip_pressure=0.20
  Z: bf_Z=0.30

frustration:
  conf: low_est
  L: mcd=0.20 brow_tension=0.25 jaw_tension=0.20
  M: mcd=0.35 brow_tension=0.45 jaw_tension=0.40 lip_pressure=0.20
  H: mcd=0.50 brow_tension=0.65 jaw_tension=0.60 lip_pressure=0.35 nf=0.15
  Z: none

resignation:
  conf: low_est
  L: mcd=0.15 esq=0.10 brow_tension=0.10
  M: mcd=0.25 esq=0.20 brow_tension=0.20 jaw_tension=-0.15
  H: mcd=0.40 esq=0.30 brow_tension=0.30 jaw_tension=-0.25 jaw=0.05
  Z: none

melancholy:
  conf: low_est
  L: mcd=0.15 bf=0.20 esq=0.15 brow_tension=0.10
  M: mcd=0.25 bf=0.35 esq=0.25 brow_tension=0.20
  H: mcd=0.40 bf=0.55 esq=0.35 brow_tension=0.35 lip_pressure=0.15
  Z: bf_Z=0.35

tenderness:
  conf: est
  L: mcl=0.20 esq=0.15 brow_tension=-0.10
  M: mcl=0.35 esq=0.25 brow_tension=-0.15 cp=0.10
  H: mcl=0.50 esq=0.35 brow_tension=-0.20 cp=0.20
  Z: mcl_Z=0.20 cp_Z=0.15

adoration:
  conf: est
  L: mcl=0.25 eo=0.25 esq=0.10
  M: mcl=0.40 eo=0.40 esq=0.20 brow_tension=-0.10
  H: mcl=0.55 eo=0.60 esq=0.30 brow_tension=-0.15 cp=0.15
  Z: mcl_Z=0.25 eo_Z=0.35 cp_Z=0.20

suspicion:
  conf: low_est
  L: esq=0.20 brow_tension=0.20 asym=+0.25
  M: esq=0.35 brow_tension=0.35 asym=+0.45 lip_pressure=0.15
  H: esq=0.50 brow_tension=0.55 asym=+0.60 lip_pressure=0.30 mcd=0.10
  Z: none

wariness:
  conf: low_est
  L: esq=0.15 brow_tension=0.20 lip_pressure=0.10
  M: esq=0.25 brow_tension=0.35 lip_pressure=0.20 jaw_tension=0.15
  H: esq=0.40 brow_tension=0.50 lip_pressure=0.35 jaw_tension=0.30 mcd=0.10
  Z: none

calculating:
  conf: low_est
  L: esq=0.20 brow_tension=0.15 asym=+0.20
  M: esq=0.35 brow_tension=0.25 asym=+0.35 lip_pressure=0.15
  H: esq=0.50 brow_tension=0.35 asym=+0.50 lip_pressure=0.30 mcl=0.10
  Z: mcl_Z=0.10

---

## [CAT3] Social/Performative (11)

polite_smile:
  conf: est
  L: mcl=0.25
  M: mcl=0.40 mwd=0.10
  H: mcl=0.55 mwd=0.20 lip_pressure=0.10
  Z: mcl_Z=0.20

forced_smile:
  conf: est
  L: mcl=0.30 jaw_tension=0.20 lip_pressure=0.15
  M: mcl=0.50 jaw_tension=0.40 lip_pressure=0.30 brow_tension=0.15
  H: mcl=0.70 jaw_tension=0.60 lip_pressure=0.50 brow_tension=0.25
  Z: mcl_Z=0.15

bitter_smile:
  conf: est
  L: mcl=0.20 mcd=0.10 esq=0.10
  M: mcl=0.30 mcd=0.20 esq=0.20 brow_tension=0.15
  H: mcl=0.40 mcd=0.30 esq=0.30 brow_tension=0.25 lip_pressure=0.20
  Z: mcl_Z=0.15

wry_smile:
  conf: est
  L: mcl=0.25 asym=+0.40 esq=0.10
  M: mcl=0.35 asym=+0.60 esq=0.20 mcd=0.10
  H: mcl=0.45 asym=+0.80 esq=0.30 mcd=0.20 brow_tension=0.15
  Z: mcl_Z=0.20

hollow_laugh:
  conf: measured
  L: mcl=0.40 jaw=0.15 jaw_tension=0.25
  M: mcl=0.55 jaw=0.25 jaw_tension=0.45 brow_tension=0.10
  H: mcl=0.70 jaw=0.35 jaw_tension=0.65 brow_tension=0.20 lip_pressure=0.15
  Z: mcl_Z=0.30 jaw_Z=0.50

nervous_laugh:
  conf: measured
  L: mcl=0.35 jaw=0.10 brow_tension=0.15
  M: mcl=0.50 jaw=0.20 brow_tension=0.25 esq=0.10
  H: mcl=0.65 jaw=0.30 brow_tension=0.40 esq=0.20 lip_pressure=0.10
  Z: mcl_Z=0.25 jaw_Z=0.30

smug:
  conf: low_est
  L: mcl=0.20 asym=+0.30 esq=0.10
  M: mcl=0.30 asym=+0.50 esq=0.20 brow_tension=-0.10
  H: mcl=0.40 asym=+0.70 esq=0.30 brow_tension=-0.15 cp=0.10
  Z: mcl_Z=0.15 cp_Z=0.10

arrogance:
  conf: low_est
  L: mcl=0.10 brow_tension=-0.15 esq=0.15 mcd=0.05
  M: mcl=0.15 brow_tension=-0.25 esq=0.25 mcd=0.10
  H: mcl=0.20 brow_tension=-0.35 esq=0.35 mcd=0.20 asym=+0.30
  Z: none

mockery:
  conf: low_est
  L: mcl=0.20 asym=+0.45 esq=0.15 mcd=0.10
  M: mcl=0.30 asym=+0.65 esq=0.25 mcd=0.20 brow_tension=0.10
  H: mcl=0.40 asym=+0.85 esq=0.35 mcd=0.30 brow_tension=0.20
  Z: mcl_Z=0.15

playful:
  conf: est
  L: mcl=0.35 asym=+0.25 br=0.20
  M: mcl=0.50 asym=+0.40 br=0.35 esq=0.10
  H: mcl=0.65 asym=+0.55 br=0.50 esq=0.20 jaw=0.10
  Z: mcl_Z=0.35 br_Z=0.35

speaking:
  conf: measured
  L: jaw=0.20 mwd=0.15
  M: jaw=0.45 mwd=0.30
  H: jaw=0.75 mwd=0.50
  Z: jaw_Z=0.50

---

## [CAT4] Transitional/Suppressed (6)

suppressing_tears:
  conf: est
  L: bf=0.25 esq=0.10 lip_pressure=0.25 jaw_tension=0.20 eye_wet=0.30
  M: bf=0.45 esq=0.20 lip_pressure=0.45 jaw_tension=0.40 eye_wet=0.60
  H: bf=0.65 esq=0.30 lip_pressure=0.65 jaw_tension=0.60 mcd=0.15 eye_wet=0.85
  Z: bf_Z=0.55

suppressing_laugh:
  conf: est
  L: lip_pressure=0.40 esq=0.15 jaw_tension=0.25
  M: lip_pressure=0.60 esq=0.25 jaw_tension=0.45 mcl=0.10
  H: lip_pressure=0.80 esq=0.35 jaw_tension=0.65 mcl=0.20 cp=0.15
  Z: mcl_Z=0.10 cp_Z=0.10

choking_up:
  conf: est
  L: bf=0.35 jaw_tension=0.30 mcd=0.15 lip_pressure=0.30 eye_wet=0.40
  M: bf=0.55 jaw_tension=0.55 mcd=0.25 lip_pressure=0.50 jaw=0.05 eye_wet=0.65
  H: bf=0.75 jaw_tension=0.75 mcd=0.40 lip_pressure=0.65 jaw=0.10 eye_wet=0.85
  Z: bf_Z=0.55 jaw_Z=0.15

crying_while_smiling:
  conf: measured
  L: mcl=0.25 bf=0.25 mcd=0.10 eye_wet=0.35
  M: mcl=0.40 bf=0.40 mcd=0.15 esq=0.10 eye_wet=0.60
  H: mcl=0.55 bf=0.55 mcd=0.20 esq=0.15 cp=0.15 eye_wet=0.80
  Z: mcl_Z=0.25 bf_Z=0.40 cp_Z=0.15

shock:
  conf: measured
  L: eo=0.60 br=0.55 jaw=0.25 lip_pressure=0.10
  M: eo=0.80 br=0.75 jaw=0.45 lip_pressure=0.05 brow_tension=0.15
  H: eo=1.00 br=1.00 jaw=0.70 brow_tension=0.30 jaw_tension=0.20
  Z: br_Z=1.00 eo_Z=1.00 jaw_Z=0.70

dissociation:
  conf: low_est
  L: esq=0.05 brow_tension=-0.05
  M: esq=0.10 brow_tension=-0.10 jaw_tension=-0.20
  H: esq=0.15 brow_tension=-0.15 jaw_tension=-0.35 jaw=0.05
  Z: none

---

## [CAT5] Physical States (6)

pain:
  conf: measured
  L: bf=0.45 brow_tension=0.40 esq=0.25 jaw_tension=0.30
  M: bf=0.70 brow_tension=0.65 esq=0.40 jaw_tension=0.55 mcd=0.20
  H: bf=0.95 brow_tension=0.90 esq=0.55 jaw_tension=0.80 mcd=0.35 nf=0.20
  Z: bf_Z=0.90

exhaustion:
  conf: est
  L: esq=0.15 brow_tension=-0.05 mcd=0.05
  M: esq=0.30 brow_tension=-0.10 mcd=0.10 jaw=0.05
  H: esq=0.50 brow_tension=-0.15 mcd=0.20 jaw=0.10 lip_pressure=-0.20
  Z: none

nausea:
  conf: low_est
  L: nf=0.20 mcd=0.15 esq=0.10
  M: nf=0.40 mcd=0.30 esq=0.20 brow_tension=0.15
  H: nf=0.60 mcd=0.45 esq=0.30 brow_tension=0.25 jaw_tension=0.20
  Z: none

drowsy:
  conf: est
  L: esq=0.20 brow_tension=-0.10
  M: esq=0.40 brow_tension=-0.15 mcd=0.05
  H: esq=0.65 brow_tension=-0.20 mcd=0.10 jaw=0.05
  Z: none

drunk:
  conf: measured
  L: mcl=0.20 esq=0.10 asym=+0.20
  M: mcl=0.30 esq=0.25 asym=+0.35 jaw=0.10
  H: mcl=0.35 esq=0.40 asym=+0.50 jaw=0.20 brow_tension=-0.15
  Z: mcl_Z=0.15 jaw_Z=0.20

yawning:
  conf: measured
  L: jaw=0.55 mwd=0.40 esq=0.20 br=0.15
  M: jaw=0.75 mwd=0.60 esq=0.35 br=0.25 jw=0.30
  H: jaw=1.00 mwd=0.85 esq=0.50 br=0.35 jw=0.55
  Z: jaw_Z=1.00 br_Z=0.30

---

## [META]
version: v1.7.1
total: 64 | CAT1:11 | CAT2:28 | CAT3:11 | CAT4:6 | CAT5:6
Z_coverage: 43_with_Z | 21_Z:none | 64_total
conf_dist: low_est:28 | est:23 | measured:13
extend_rules: ratio∈[0.0,1.0] | neg_soft_ok | unused_fields=0 | L/M/H progressive
             Z_ratio∈[0.0,1.0] | Z:none_if_planar_only | Z_block_required_for_new_exprs
             conf_required_for_new_exprs | do_not_apply_if_person_ML_conf<min_conf

# AIFS v1.7.0-compact
# AI Identity Fidelity System — geometry-anchored identity lock for portrait generation
# Unit: 1 AU = 1 IPD. Origin: pupil midpoint. X→right+. Y→down+. Z→outward+. Z=0: pupil plane.
# Core: Identity > Beauty > Expression | Geometry > Semantics | Region > Monolith | Ratio > Absolute
#       Geometry Is Position | AI Paints Structure Stays | View-Constrained Honesty
# Companion: AIFS_ExprLib_v1_7_1-compact.md (expression library module, required for EXPR calls)

---

## [UNIT] AU Anchors
HA1 = IPD = 1.000 AU (absolute, never changes)
HA2 = ICD / IPD
HA3 = NW / IPD
OCD_check: OCD_calc = ICD + 2×EL; Δ ≤ 0.04 AU → ✅

---

## [LM] 15-Point Landmark (anchor = neutral front, no glasses)
L01(-0.5,0) L02(+0.5,0) [fixed]
L03=med_cant_L  L04=med_cant_R
L05=lat_cant_L  L06=lat_cant_R
L07=nasion      L08=subnasale
L09=alar_L      L10=alar_R
L11=labiale_sup
L12=cheilion_L  L13=cheilion_R
L14=gonion_L    L15=menton
Validation: L03-L04=ICD±0.02 | L09-L10=NW±0.02 | L12-L13=MW±0.03 | L07-L08=MFH±0.03

---

## [SCAN] G1–G9 Fields (AI visual estimation → output as numbers, no [MEASURE])
G1: face_shape | thirds_upper/mid/low(norm/short/long)
G2: eyelid_type | canthal_tilt_deg(+up/-down) | under_eye_fat[0-1] | EL_AU | ICD_AU
G3: nose_tip_shape | bridge_height(low/med/high) | NW_AU | nasolabial_deg | proj(flat/mod/proj)
G4: lip_ratio(up:down) | MW_AU | philtrum_AU | corner_lift_deg(+up/-down)
G5: chin_shape | jaw_width_AU | jaw_angle_deg | mandibular_def(soft/mod/sharp)
G6: FW_AU | zygomatic_pos(low/mid/high) | cheek_fullness(flat/mod/full)
G7: notable_features[(name:safe/lock)] | asymmetry(low/mod/high) | skin | glasses_variant
G8: confidence(H/M/L) | skull_W_AU | skull_D_AU | forehead_curve(flat/mod/prom) | orbital_depth(sh/avg/deep) | zygomatic_arc_ratio | mandible_D_AU | chin_vol(flat/mod/proj)
# G8: frontal=estimated | 45° refines zygAR | 90° refines skull_D+mandible_D
G9: [built after Phase 0F / SCAN:DUAL] confidence(H/M/L) | 12 sparse skeleton pts (X,Y,Z)
# G9 pts: nasion | nose_tip | subnasale | orbital_L | orbital_R | glabella | menton | gonion_L | pogonion | zygomatic_L | zygomatic_R | frontal_boss
# X,Y from frontal LM coords | Z from 90° side photo (measured) or inherited from G8 (estimated)
# G9→G8 upgrade: mandible_D = menton.Z | skull_D ≈ frontal_boss.Z | nose_proj = nose_tip.Z

---

## [ML] Muscle Limits (Phase 0E — scan from photos; used by ExprLib ratio calc)
# From photo scan (H=direct read | M=interpolated | estimated=neutral-only typical values)
ML_mcl=[v]  # corner lift max (AU)       typical 0.15–0.25
ML_mcd=[v]  # corner pull max (AU)       typical 0.05–0.12
ML_mwd=[v]  # corner spread max (AU)     typical 0.08–0.18
ML_jaw=[v]  # jaw open max (AU)          typical 0.20–0.40
ML_esq=[v]  # eye squeeze max (AU)       typical 0.04–0.08
ML_eo=[v]   # eye open max (AU)          typical 0.03–0.06
ML_br=[v]   # brow raise max (AU)        typical 0.04–0.08
ML_bf=[v]   # brow furrow max (AU)       typical 0.02–0.05
ML_cp=[v]   # cheek push max (AU)        typical 0.08–0.15
ML_nf=[v]   # nostril flare max (AU)     typical 0.03–0.06
ML_jw=[v]   # jaw width max Δ (AU)       typical 0.05–0.12
ML_conf=[H/M/estimated]
# H = laugh+surprise photos available | M = smile photos | estimated = neutral only
# ML_Z_derived (auto-calc after Phase 0E, no extra scan):
ML_jaw_Z=ML_jaw×0.25  ML_cp_Z=ML_cp×0.40  ML_mcl_Z=ML_mcl×0.25
ML_bf_Z=ML_bf×0.25    ML_br_Z=ML_br×0.20   ML_eo_Z=ML_eo×0.12

---

## [G9] Sparse Skeleton Coordinates (Phase 0F — built after side photo)
# Z=0: pupil plane. Z+: toward viewer. Z−: away. All AU.
# confidence per point: measured (side photo) | estimated (G8-derived) | N_A
nasion:       X=0.000  Y=[L07_y]  Z=___  conf=___
nose_tip:     X=0.000  Y=___      Z=___  conf=___   # highest Z on face
subnasale:    X=0.000  Y=[L08_y]  Z=___  conf=___
orbital_L:    X=-0.500 Y=0.000    Z=___  conf=___   # Z typically −0.05~−0.20
orbital_R:    X=+0.500 Y=0.000    Z=___  conf=___
glabella:     X=0.000  Y=___      Z=___  conf=___   # brow ridge
menton:       X=0.000  Y=[L15_y]  Z=___  conf=___   # Z typically +0.15~+0.35
gonion_L:     X=-[jaw/2] Y=[L14_y] Z=___ conf=___
pogonion:     X=0.000  Y=___      Z=___  conf=___
zygomatic_L:  X=___    Y=___      Z=___  conf=___   # from 45° photo
zygomatic_R:  X=___    Y=___      Z=___  conf=___
frontal_boss: X=0.000  Y=___      Z=___  conf=___
G9_conf=[H(≥9meas)/M(≥6)/L(<6)]

---

## [MPIF] Multi-Plane Identity Field (built after G9)
# Parallax formula: Δx = Z_plane × tan(θ)  [AU, θ in degrees]
P1_foreground: Z>+0.20  → nose_tip, glabella, zygomatic(if>0.20) | drift_risk🔴
P2_midface:    Z+0.05~+0.20 → nasion, subnasale, pogonion, lips | drift_risk🟡
P3_orbital:    Z≈0     → L01/L02 (Z=0 ref), eye corners, gonion | drift_risk🔴(IPD abs)
P4_recessed:   Z−0.05~−0.20 → orbital_L/R | drift_risk🟡
P5_cranial:    Z<−0.20 → frontal_boss, occipital(est) | drift_risk🟢
MPIF_ready: yes(≥3 measured Z) | partial | no
parallax_calculable: yes | no

---

## [AB] AI Boundary
LOCKED(AI cannot decide):
  geometry: IPD=abs | ICD±0.03 | NW≥BL_floor | jaw≥BL_floor | all G9 X,Y coords
  depth:    nose_tip.Z±0.05(fixed) | orbital.Z±0.03(fixed) | menton.Z neutral±0.05(expr→Z_eff by ExprLib) | zygomatic.Z neutral(expr→Z_eff) | glabella.Z neutral(expr→Z_eff)
  expr_Z_rule: during expressions, G9_Z = neutral_Z + EXP_DELTA_Z (set by ExprLib Z_ratio×ML_Z_derived). AI must NOT add/remove Z beyond this formula.
  topology: L01-L06 (X,Y) | canthal_tilt_dir | eyelid_type | fat(if>0.3) | G7_lock_items
FREE(AI decides):
  surface: pore/skin texture | lighting/shadow | makeup | color tone
  micro:   fine wrinkles | lash/brow detail | lip texture | hair
  style:   photo vs painterly | bokeh | color grade | beauty within BL

---

## [VC] View Constraint
effective:  horiz±30° | vert±15° | roll±10°  → full MPIF constraints active
marginal:   horiz 30–50° → generate + tag identity_confidence:marginal
out:        horiz>50° → warn or refuse; identity guarantee void
GEN:ANGLE policy: in_range=normal | marginal=warn+generate | out=⚠️prompt user

---

## [RL] Region Lock Rules
OB🔴: IPD=1.000abs | ICD±0.03 | canthal_tilt_dir_locked | eyelid_type_locked | under_eye_fat_locked(if>0.3) | EL±0.03 | eye_h≤BL_ceil
NA🔴: NW≥BL_floor | bridge±0.03 | tip_type_locked | nasolabial±5° | tip_proj≤BL_ceil
MA🔴: jaw≥BL_floor | jaw_angle±5° | chin_shape_locked | mandD±0.08(if G8) | def_locked
MF🟡: zyg_pos_locked | FW≥BL_floor | zyg_proj±0.05(if side_data)
OR🟡: philtrum±0.03(neutral) | lip_ratio±0.10(neutral) | MW_neutral±0.05
UF🟢: temporal_W±0.05 | forehead_curve_type_locked

---

## [BL] Beauty Hard Limits
# Level:           1      2      3      4      5
jaw_floor:       ×0.97  ×0.92  ×0.88  ×0.85  ×0.82
FW_floor:        ×0.97  ×0.93  ×0.90  ×0.87  ×0.83
NW_floor:        ×0.98  ×0.95  ×0.93  ×0.90  ×0.87
tip_proj_Δceil:  +0.00  +0.00  +0.00  +0.04  +0.06
eye_h_Δceil:     +0.00  +0.00  +0.00  +0.02  +0.03
default_level: 2

---

## [COV] Coverage Matrix
# Symbol: ✅direct ⚠️estimated ❌none
# Angle×Expr 32 cells: [front/15°/45°/90°] × [neutral/smile_s/smile_o/laugh/surprise/serious/speaking/contempt]
# Light×Angle 20 cells: [even_nat/side_light/indoor_warm/indoor_white/nat_shade] × [front/15°/45°/90°]
# 3D: frontal_est | side45_zygAR | profile90_skulD+mandD
coverage_total = ang_expr_n/32 + lighting_n/20 → total/52

---

## [TIER] Data Requirements
T1(min): ≥5 photos | neutral_front+45°+90° + smile_o_front + 3_lights | fidelity~60%
         bonus: 90°_side_photo → builds G9 Z-axis, major parallax upgrade
T2(stable): ≥15–25 | T1 + neutral_15° + laugh+surprise_front + side_light+indoor
            + 90°_side_photo (v1.7: required for T2) → G9+MPIF active | fidelity~75%
            # without side photo: G9 all estimated, MPIF shell only, degrades to v1.6 mode
T3(full): ≥40–80 | T2 + 24grid + 5lights×front+45° + tilt_up+down + speaking_frames
          + 45°L+45°R (→ G9_zygomatic Z) + multi-angle frames (→ expand VC range) | fidelity~90%

---

## [LOCK] Phase 3 Lock Vector
= {HA1,HA2,HA3 | G1–G9_values | BL_floors_at_level | LM_coords | RL_rules | ML_values | G9_Z_values | MPIF_Z_refs | ANTI_keywords | notable_lock_items}
cranial_lock: skull_W±0.08 | skull_D±0.10 | fore_type_locked | orb_depth_locked | zygAR±0.04 | mandD±0.08(→G9_menton.Z if measured) | chin_vol_locked
LM_lock: L03-L04=ICD±0.02 | L09-L10=NW±0.02 | L14≥jaw_floor | L15±0.04
         2.5D: if G9_ready → each LM pt Z locked ±0.05 AU
ML_lock: [ML_mcl|ML_mcd|ML_mwd|ML_jaw|ML_esq|ML_eo|ML_br|ML_bf|ML_cp|ML_nf|ML_jw|ML_conf]
ML_Z_derived: jaw_Z=ML_jaw×0.25 | cp_Z=ML_cp×0.40 | mcl_Z=ML_mcl×0.25 | bf_Z=ML_bf×0.25 | br_Z=ML_br×0.20 | eo_Z=ML_eo×0.12
G9_lock: nose_tip.Z±0.05 | menton.Z±0.05 | orbital.Z±0.03 | nasion.Z±0.05 | glabella.Z±0.05 | zyg.Z±0.05
         hard_lock=measured pts | soft_lock=estimated pts | G9_lock_active=yes(≥3meas)/partial/no
MPIF_lock: P1_Z_ref=nose_tip.Z | P2_Z_ref=avg(nasion.Z,pogonion.Z) | P3_Z_ref=0.000 | P4_Z_ref=orbital.Z | P5_Z_ref=frontal_boss.Z

---

## [GEN] Phase 4 Prompt Template
```
realistic photo of a [age]-year-old [sex],
[OB🔴] eye spacing [ICD] AU, [+up/-down] outer corners [|tilt|]°, [eyelid_type], [under_eye_fat_desc], eye width [EL] AU,
[NA🔴] nose width [NW] AU, bridge [nasal_bridge] AU wide, nasolabial [naslabA]°, [tip_shape] tip,
        [if G9_nose_tip.Z measured] nose tip protrudes [nose_tip.Z] AU from eye plane,
[MA🔴] jaw [jaw_W] AU wide, jaw angle [jawA]°, [def] jawline, [chin_shape] chin, skull depth [skulD] AU,
        [if G9_menton.Z measured] chin projects [menton.Z] AU forward,
[MF🟡] face width [FW] AU, [zyg_pos] cheekbones,
[G8 if conf≥M] skull width [skulW] AU, [fore_curve] forehead, [orb_depth] orbital depth,
        [if G9_orbital.Z measured] eye sockets recessed [|orbital.Z|] AU,
[EXPR if≠neutral] XY: [expanded from ExprLib ratio×ML] | Z: [expanded from ExprLib Z_ratio×ML_Z_derived]
        XY examples: mouth corners raised [Δmcl] AU, cheeks lifted [Δcp] AU, jaw open [Δjaw] AU
        Z  examples: cheeks pushed forward [Δcp_Z] AU, jaw slightly receded [Δjaw_Z] AU, mouth corners forward [Δmcl_Z] AU
[MPIF if parallax_ready=yes AND angle≠0°]
  [neutral] nose tip shifts [nose_tip.Z×tan(θ)] AU | chin shifts [menton.Z×tan(θ)] AU | eye width [cos(θ)] AU
  [expr≠neutral] nose tip shifts [nose_tip.Z×tan(θ)] AU | chin shifts [menton_Z_eff×tan(θ)] AU
                 cheekbones shift [zygomatic_Z_eff×tan(θ)] AU | mouth corners shift [lips_Z_eff×tan(θ)] AU
                 eye width [cos(θ)] AU
  # Z_eff = G9_[pt].Z + EXP_DELTA_Z (neutral degrades to G9_Z, backward compatible)
[SCENE] [lighting] [angle] 85mm photorealistic sharp focus,
[ANTI] no V-shaped face, jaw ≥[jaw_floor] AU, no eye enlargement, no nose narrowing, no skull compression,
       [if G9_active] flat face, no facial depth, 2D face projection,
       [G7_lock_anti_items], lighting shadow is not facial structure
```

---

## [EXPR] ExprLib Expansion (v1.7.1)
# Call: AIFS:GEN:EXPR [name] [low/medium/high] (default: medium)
# XY calc: delta_XY = ratio × ML_lock_value | T4 auto-pass: ratio≤1.0 → delta≤ML
# Z  calc: delta_Z  = Z_ratio × ML_Z_derived | Z_eff = person.G9_[pt].Z + delta_Z
# conf_check: person.ML_conf ≥ expr.min_conf required; else tag identity_confidence:low
# Manual delta (non-ExprLib): still requires delta ≤ ML check
expr_fields: mcl×ML_mcl | mcd×ML_mcd | mwd×ML_mwd | jaw×ML_jaw | esq×ML_esq | eo×ML_eo | br×ML_br | bf×ML_bf | cp×ML_cp | nf×ML_nf | jw×ML_jw
Z_fields:    jaw_Z×ML_jaw_Z | cp_Z×ML_cp_Z | mcl_Z×ML_mcl_Z | bf_Z×ML_bf_Z | br_Z×ML_br_Z | eo_Z×ML_eo_Z
soft_fields: jaw_tension[0-1] | brow_tension[-1~+1] | lip_pressure[0-1] | eye_wet[0-1] | asym[-1~+1]

---

## [VALID] Phase 5 Thresholds
T1→reject_now: IPD_Δ=0.00abs | ICD_Δ≤±0.03 | NW∈[BL_floor, NW+0.05]
T2→reject: OB(tilt±2°_no_dir_reversal | EL±0.03 | eye_h≤ceil) | NA(bridge±0.03 | tip≤ceil) | MA(jaw≥floor | angle±5° | mandD±0.10) | MF(FW≥floor → warn_only)
T3→reject: L03/04_Δ≤±0.03 | L09/10_Δ≤±0.03 | L14_x≥jaw_floor | L15_Δ≤±0.04
T4→reject: any ExprLib_ratio>1.0 OR manual_delta>ML | auto_pass if called correctly from ExprLib
T5→reject: eyelid_type≠LOCK | notable(lock) not visible
T6→reject: [only if MPIF_ready=yes AND angle≠0°]
           nose_tip parallax Δ>±0.04AU vs predicted(nose_tip.Z×tan(θ))
           menton parallax Δ>±0.05AU vs predicted(menton_Z_eff×tan(θ))
           # menton_Z_eff = G9_menton.Z + EXP_DELTA_jaw_Z (neutral: Z_eff = G9_Z)
           IPD perspective Δ>±0.03AU vs predicted(cos(θ))
           skip if MPIF not built or angle=0°
Order: T1→T2→T3→T4→T5→T6. T1_fail=stop_all. ≥3_total_fails → lower_level or add_photos.

---

## [CORRECT] Phase 6 Drift Fix
cranial_3D_drift      → prompt+: skull_W/D/fore/jawA/mandD | neg+: skull distortion, face shape change from angle
orbital_drift         → prompt+: reinforce ICD/EL/tilt/eyelid/fat values
mandibular_drift      → prompt+: "jaw width [val] AU, not less than [floor] AU"
nasal_drift           → prompt+: "nose width [val] AU, alar base [val] AU"
shadow_misread        → prompt+: "lighting shadow is not facial structure" | neg+: sunken cheek, shadow-defined jawline
expr_ratio_drift      → lower ExprLib intensity: high→medium→low | or rescan ML with more photos
G9_geometry_drift     → [T6 fail] prompt+: "nose tip protrudes [Z] AU | chin projects [Z] AU | eye sockets recessed [Z] AU | at [θ]° nose shifts [Δx] AU"
                        neg+: flat face, no facial depth, 2D face projection
view_constraint_viol  → angle>30°: lower to ≤30° or tag identity_confidence:low | long-term: add mid-angle photos

---

## [SIDE] Side View Protocol → Phase 0F Z-Axis Calibration (v1.7)
# Triggered by: AIFS:SCAN:DUAL or AIFS:SCAN:SIDE (upgraded)
Step1 scale_check: side_px_per_AU / front_px_per_AU → accept 0.85–1.15
Step2 Y-align: pupil_height or subnasale as horizontal ref between front+side
Step3 Z-extract: measure each G9 pt's horizontal dist from eye-vertical-line → convert to AU
Step4 Z-validate: nose_tip.Z∈[+0.15,+0.45] | glabella.Z∈[+0.05,+0.25] | menton.Z∈[+0.05,+0.35] | orbital.Z∈[−0.05,−0.20] | nasion.Z∈[−0.05,+0.10]
                  any val >2× range → warn, suggest retake
Step5 G9 fill + G8 upgrade: mandD←menton.Z | skulD refined | confidence estimated→M(45°) or H(90°)
Step6 LM 2.5D: append Z to all 15 LM pts from G9 values (landmark_2_5D_ready=yes)
Step7 MPIF build: assign G9 pts to P1–P5 planes
Extract from 45°: zygomatic_arc_ratio + G9_zygomatic.Z
CROSSCHECK: G6_FW vs G8_skulW | G5_jawA vs MA_lock

---

## [DB] COMPACT_DB Output Format (AI-only; output after AIFS:SCAN)
# Pipe-delimited. No labels beyond field prefix. All values estimated from photo (no placeholders).
```
[LOCK_ID]|T[tier]|L[lvl]|[date]
HA|[px]px|ICD=[v]|NW=[v]|OCD_Δ=[v]|[✅/⚠️/🔴]
G1|[shape]|up=[n/s/l]|mid=[n/s/l]|low=[n/s/l]
G2|[eyelid]|tilt=[v]°|fat=[v]|EL=[v]|ICD=[v]
G3|[tip]|br=[l/m/h]|NW=[v]|nla=[v]°|proj=[f/m/p]
G4|[u:d]|MW=[v]|phil=[v]|corner=[v]°
G5|[chin]|jaw=[v]|jawA=[v]°|def=[s/m/sh]
G6|FW=[v]|zyg=[l/m/h]|cheek=[f/m/fu]
G7|feat=[[name:s/l],...]|asym=[l/m/h]|glass=[desc/none]
G8|[H/M/L]|W=[v]|D=[v]|fore=[f/m/p]|orb=[sh/av/d]|zygAR=[v]|mandD=[v]|chin=[f/m/p]
G9|[H/M/L]|[N]/12meas|nas=Z[v]|ntip=Z[v]|sub=Z[v]|orbL=Z[v]|orbR=Z[v]|glab=Z[v]|ment=Z[v]|gon=Z[v]|pog=Z[v]|zygL=Z[v]|zygR=Z[v]|front=Z[v]
LM|[✅/part/❌]|2.5D=[yes/no]|03=[x],[y]|04=[x],[y]|05=[x],[y]|06=[x],[y]|07=0,[y]|08=0,[y]|09=[x],[y]|10=[x],[y]|11=0,[y]|12=[x],[y]|13=[x],[y]|14=[x],[y]|15=0,[y]
ML|[H/M/est]|mcl=[v]|mcd=[v]|mwd=[v]|jaw=[v]|esq=[v]|eo=[v]|br=[v]|bf=[v]|cp=[v]|nf=[v]|jw=[v]
MPIF|[ready/partial/no]|P1_Z=[v]|P2_Z=[v]|P3_Z=0|P4_Z=[v]|P5_Z=[v]|parallax=[yes/no]
RL|OB🔴|NA🔴|MA🔴|MF🟡|OR🟡|UF🟢
COV|[pct]%|ang=[n]/32|lit=[n]/20|3D=[F✅/45⚠️/90✅]|G9=[N]/12
BL|L[n]|jaw=[v]|FW=[v]|NW=[v]|tipΔ=[v]|eyeΔ=[v]
ANTI|[space-sep anti keywords]
PRI|1=[photo_need]+[est%]|2=[photo_need]+[est%]|3=[photo_need]+[est%]
```

---

## [REPORT] AIFS:REPORT Format (human-readable, long format, triggered only)
```
═══════════════════════════════════════
  AIFS v1.7 · Identity Report
═══════════════════════════════════════
LOCK_ID        : ___
資料等級       : Tier ___ / 3
照片數量       : ___ 張

══ 錨點基準層 ══════════════════════════
  IPD : [px]px=1.000AU [✅/⚠️] | ICD:[v]AU | NW:[v]AU | OCD:[✅/⚠️/🔴]Δ=[v] | LM:[15pt/Xpt][✅/⚠️] | 2.5D:[yes/no]

══ G8 頭骨立體層 ════════════════════════
  W=[v]AU[H/M/est] | D=[v]AU[H/est/❌] | fore=[f/m/p] | orb=[sh/av/d] | zygAR=[v][✅/est] | mandD=[v]AU[H/est/❌] | chin=[f/m/p]

══ G9 稀疏骨架座標 ═══════════════════════
  [H/M/L] | [N]/12 measured
  ntip.Z=[v][meas/est] | nas.Z=[v] | ment.Z=[v] | orb.Z=[v] | glab.Z=[v] | zyg.Z=[v]

══ MPIF 多平面身份場 ═════════════════════
  P1(Z>[+0.20])=[pts] | P2(Z+0.05~+0.20)=[pts] | P3(Z≈0)=L01/L02 | P4(Z−0.05~−0.20)=orbital | P5(Z<−0.20)=[pts]
  ready=[yes/partial/no] | parallax=[yes/no] | VC_range=±[n]°

══ AI 決策邊界 ══════════════════════════
  locked: G9_XY + G9_Z + MPIF_planes + LM_topology + eyelid + fat(if>0.3) + G7_lock
  free: texture/lighting/micro/style/beauty_within_BL

══ ML 肌肉物理上限 ══════════════════════
  [H/M/est] mcl=[v] mcd=[v] mwd=[v] jaw=[v] esq=[v] eo=[v] br=[v] bf=[v] cp=[v] nf=[v] jw=[v]

══ 分區漂移風險 ═════════════════════════
  🔴OB: ICD=[v]AU tilt=[v]° [eyelid] fat=[v]
  🔴NA: NW=[v]AU bridge=[v]AU tip=[type]
  🔴MA: jaw=[v]AU angle=[v]° chin=[type]
  🟡MF: FW=[v]AU zyg=[pos]
  🟡OR: MW=[v]AU phil=[v]AU
  🟢UF: temporal=[v]AU fore=[type]

══ 核心幾何（AU）════════════════════════
  G1:[shape] up=[n/s/l] mid=[n/s/l] low=[n/s/l]
  G2:[eyelid] tilt=[v]° fat=[v] EL=[v] ICD=[v]
  G3:[tip] br=[l/m/h] NW=[v] nla=[v]° proj=[f/m/p]
  G4:[u:d] MW=[v] phil=[v] corner=[v]°
  G5:[chin] jaw=[v] jawA=[v]° def=[s/m/sh]
  G6:FW=[v] zyg=[l/m/h] cheek=[f/m/fu]
  G7:feat=[...] asym=[l/m/h] glass=[desc/none]

══ 美顏設定 Level [n] ═══════════════════
  jaw≥[v]AU | FW≥[v]AU | NW≥[v]AU | tipΔ≤+[v]AU | eyeΔ≤+[v]AU

══ 覆蓋狀態 ═════════════════════════════
  擬真度[████░░]XX% | Tier[n] → 補[N]張至Tier[n+1]
  ang=[n]/32 | lit=[n]/20 | G8:F[✅/⚠️]·45[✅/❌]·90[✅/❌] | G9:[N]/12meas
優先補充: 1.[need]+est% | 2.[need]+est% | 3.[need]+est%
═══════════════════════════════════════
```

---

## [CMDS]
| Cmd | Action |
|-----|--------|
| AIFS:SCAN | Ph0(HA+LM+ML)+Ph1(G1-G9) → output COMPACT_DB |
| AIFS:SCAN:DUAL | front+side photos → Ph0A-0F + G9 + MPIF + LM_2.5D → full COMPACT_DB |
| AIFS:SCAN:SIDE | SIDE_VIEW_PROTOCOL v1.7 → Z-axis calibration + G9 + MPIF |
| AIFS:ANCHOR | show HA1-3 + OCD + LM status |
| AIFS:ANCHOR:RECALIBRATE | recalibrate IPD |
| AIFS:LANDMARK | show 15pt coords (+ Z if 2.5D ready) |
| AIFS:REGION | show RL per zone |
| AIFS:3D | show G8 + confidence |
| AIFS:SKELETON | show G9 coords (X/Y/Z per point) + G9_conf |
| AIFS:MPIF | show MPIF planes + Z_refs + parallax_ready |
| AIFS:BOUNDARY | show AI_BOUNDARY (locked vs free) |
| AIFS:CROSSCHECK | FRONTAL_SIDE_CROSSCHECK |
| AIFS:DATA | show tier + COV gaps |
| AIFS:ML | show ML values + confidence |
| AIFS:BEAUTY [1-5] | set level (default 2) |
| AIFS:LOCK | show full LOCK vector (G8+G9+MPIF+LM+ML) |
| AIFS:GEN [desc] | Phase 4 prompt (neutral) |
| AIFS:GEN:EXPR [name] [low/med/high] | Phase 4 + ExprLib expansion (default med) |
| AIFS:GEN:ANGLE [a] | Phase 4 + angle; auto VC check → warn if >±30° |
| AIFS:PARALLAX [a] | calc Δx per MPIF plane at angle [a]: Δx=Z×tan(θ) |
| AIFS:VALIDATE | Phase 5 delta check (T1–T6) |
| AIFS:UPDATE | upload photo → update LOCK+ML |
| AIFS:REPORT | full human-readable report |
| AIFS:EXPRLIB | list available expressions from ExprLib |

---

## [RULES]
1. Identity > beauty. Geometric framework = absolute boundary. Beauty operates within it.
2. Micro-features define identity (under_eye_fat, eyelid_type, chin_shape, asymmetry).
3. HA anchors = ground truth. Never overridden.
4. IPD = universal ruler. All ratios scale-invariant.
5. Expression within ExprLib envelope. XY geometry (IPD/ICD/NW/jaw width) unchanged by expression. Z geometry follows ExprLib Z_ratio×ML_Z_derived biomechanics (Z_eff = neutral_Z + EXP_DELTA_Z).
6. Side photos refine depth only. Do not override frontal AU values.
7. Lighting ≠ bone structure. Shadow = light; never interpret as geometry.
8. OB/NA/MA🔴 = fully constrained always. UF🟢 = generative freedom allowed.
9. All "slight/moderate/significant" → replace with AU threshold. VALIDATE accepts numbers only.
10. Prompt = tendency. True fidelity ceiling needs LoRA+IP-Adapter+ControlNet+ArcFace. AIFS = prompt-only optimum.
11. Ratio > Absolute. ExprLib ratio×ML = delta. ratio≤1.0 → T4 auto-pass. ExprLib is plug-in; swap without rewriting core.
16. Dual-view = Z-axis source. Front photo → X,Y identity. Side photo → Z identity. No Z = 2D projection, not spatial structure. G9 measured Z values are never overridden by estimates.
17. AI decides surface only, not skeleton. AI_BOUNDARY defines two zones. G9/MPIF/LM are set by measured data. AI fills surface detail within that frame. This rule overrides all prompt preferences.
18. ±30° = effective guarantee range. Beyond this AIFS cannot provide equivalent identity fidelity. View-Constrained Honesty: do best within range; do not pretend coverage outside it.
19. Expression Z follows biomechanics, not lock. During expressions, G9 Z values move according to ExprLib Z_ratio×ML_Z_derived — jaw recedes, cheeks advance, brows project. Locking Z produces puppet faces. Z_eff = neutral_Z + EXP_DELTA_Z is the only correct formula.
